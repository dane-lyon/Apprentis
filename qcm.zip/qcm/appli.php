<?php
    session_start();
    header("content-type:text/html; charset=UTF-8");
    require("Include/Header/header.htm");

    if(isset($_SESSION["Auth"]) == false)
    {
        $_SESSION["Auth"] = false;
    }

    if($_SESSION["Auth"] == false)
    {
        include("Vu/form_login.php");
        exit();
    }
    else
    {
        include("Model/Cutilisateur.php");
        $unUser = new Cutilisateur($_SESSION["Id"]);
        include("Vu/template.php");
    }
?>
