<?php
    session_start();
    header("Location: appli.php");
    exit();
?>
