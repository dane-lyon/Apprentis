<body>
    <!-- NAVBAR -->
    <div class="navtop">
        <div class="container">
            <nav class="navbar navbar-inverse">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"
                            aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand">QCM</a>
                    </div>

                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav">
                            <li id="btn_accueil" class="active" onclick="navigation(this, 'btn_accueil');">
                                <a href="#">Accueil</a>
                            </li>
                            <li id="btn_creer" onclick="navigation(this, 'btn_creer');">
                                <a href="#">Créer</a>
                            </li>
                            <li id="btn_gerer" onclick="navigation(this, 'btn_gerer');">
                                <a href="#">Gérer</a>
                            </li>
                        </ul>
                        <ul class="nav navbar-nav navbar-right">
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                    <?php echo $unUser->getIdentifiant(); ?>
                                    <span class="caret"></span>
                                </a>
                                <ul class="dropdown-menu">
                                    <?php
                                if ($unUser->getRang() == "administrateur") {
                                    echo '
                                        <li onclick="navigation(this, \'admin\');">
                                            <a href="#">Administration</a>
                                        </li>';
                                }
                            ?>
                                    <li onclick="navigation(this, 'compte');">
                                        <a href="#">Mon compte</a>
                                    </li>
                                    <li role="separator" class="divider"></li>
                                    <li>
                                        <a href="./Control/logout.php">Déconnexion</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    </div>

    <!--BODY -->

    <div class="Corps thumbnail container bg-secondary">

        <!-- ACCUEIL -->

        <div id="accueil">
            <center>
                <h3>Vous utilisez l'outil de création de QCM</h3>
            </center>
            </br>
            <div class="accueil">
                <center>
                    <h3>La documentation de l'application :</h3>
                </center>
                </br>
                </br>
                <center>
                    <a href="Include/Pdf/faux_pdf.pdf" target="_blank">
                        <button type="button" class="btn btn-info" style="color:IndianRed">
                            <i class="fa fa-file-pdf-o" style="border-radius:8px;background-color:grey; font-size:30px; color:red"></i>
                            <b>Visionner/Télécharger la documentation au format PDF</b>
                        </button>
                    </a>
                </center>
                </br>
                </br>
                <center>
                    <h3>Aide et conseils :</h3>
                </center>
                </br>
                </br>
                <h4 style="text-indent: 40px;">
                    <u>
                        Excepteur sint occaecat :
                    </u>
                </h4>
                </br>
                <blockquote style="text-indent: 20px;">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est
                    laborum.
                </blockquote>
                </br>
                </br>
                <h4 style="text-indent: 40px;">
                    <u>
                        Excepteur sint occaecat :
                    </u>
                </h4>
                </br>
                <blockquote style="text-indent: 20px;">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est
                    laborum.
                </blockquote>
                </br>
                </br>
                <h4 style="text-indent: 40px;">
                    <u>
                        Excepteur sint occaecat :
                    </u>
                </h4>
                </br>
                <blockquote style="text-indent: 20px;">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est
                    laborum.
                </blockquote>
                </br>
                </br>
                <h4 style="text-indent: 40px;">
                    <u>
                        Excepteur sint occaecat :
                    </u>
                </h4>
                </br>
                <blockquote style="text-indent: 20px;">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est
                    laborum.
                </blockquote>
            </div>
        </div>

        <!-- CRÉER -->

        <div id="creer" class="hide">
            <center>
                <h3>Vous êtes dans le menu de création</h3>
            </center>
            <div style="padding: 40px;">
                <div id="fPart">
                    <div class="form-group form-inline">
                        <label>Nom du QCM :</label>
                        <input style="width: 80%;  float: right; margin-right: 48px;" type="text" class="form-control" placeholder="Libellé du QCM">
                    </div>
                    </br>
                    <hr>
                    <center>
                        <h4>Profils</h4>
                    </center>
                    </br>
                    <div class="form-group form-inline">
                        <label>Profil :</label>
                        <input style="width: 80%; float: right; margin-right: 48px;" type="text" class="form-control" placeholder="Libellé du profil">
                    </div>
                    <div id="profil"></div>
                    <button type="button" class="btn btn-sm btn-primary" onclick="CreateBox('Profil','profil');">Ajouter un champ</button>
                    </br>
                    <hr>
                    <center>
                        <h4>Question</h4>
                    </center>
                    </br>
                    <div class="form-group form-inline">
                        <label>Question :</label>
                        <input id="q0" style="width: 80%;  float: right; margin-right: 48px;" type="text" class="form-control" placeholder="Libellé de la question">
                    </div>
                    <div id="question"></div>
                    <button type="button" class="btn btn-sm btn-primary" onclick="CreateBox('Question','question');">Ajouter un champ</button>
                    </br>
                    </br>
                    </br>
                    </br>
                    <blockquote>
                        <p class="bg-info" style="padding: 20px;">
                            Les réponses se créent sur la prochaine page.</br>
                            Vérifiez que vos profils et vos questions vous conviennent.</br>
                            Une fois vérifiés, cliquez sur le bouton
                            <b>suivant</b>.</br>
                            </br>
                            <small>
                                <u>Note :</u> Vous pourrez toujours revenir en arrière.</small>
                        </p>
                    </blockquote>
                    <button style="float: right;" onclick="tooglePart('suivant');" type="button" class="btn btn-sm btn-primary">Suivant
                        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                    </button>
                </div>
                <div id="sPart" class="hide">
                    <center>
                        <h4>Réponse</h4>
                    </center>
                    <div class="form-group form-inline">
                        <label>Réponse :</label>
                        <select id="QtoR0"></select>
                        <input type="text" class="form-control" placeholder="Libellé de la reponse">
                    </div>
                    <div id="reponse"></div>
                    <button type="button" class="btn btn-sm btn-primary" onclick="CreateBox('Réponse','reponse');">Ajouter un champ</button>
                    </br>
                    </br>
                    <button style="float: left;" onclick="tooglePart('precedent');" type="button" class="btn btn-sm btn-primary">
                        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span> Précédent</button>
                </div>
            </div>
        </div>

        <!-- GÉRER -->

        <div id="gerer" class="hide">
            <center>
                <h3>Vous êtes dans le menu d'administration de vos QCM</h3>
            </center>
            </br>
            <div class="panel panel-info">
                <div class="panel-body bg-info">
                    Listes des QCM modifiables
                </div>
                <div class="panel-footer">
                    <table id="TabQcm" class="display table table-hover">
                        <thead>
                            <tr>
                                <th class="active col-md-1">Id</th>
                                <th class="active col-md-10">Nom</th> 
                                <th class="active col-md-1">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            require("Control/bdd.php");
                            $req = "SELECT id_qcm, nom_qcm FROM QCM";
                            $response = $bdd->query($req);
                            while ($donnees = $response->fetch()) {
                                echo '<tr>';
                                echo '<td>'.$donnees["id_qcm"].'</td>';
                                echo '<td>'.$donnees["nom_qcm"].'</td>';
                                echo '<td><button onclick="Afficher_Conf_Modif(\''.$donnees["nom_qcm"].'\','.$donnees["id_qcm"].');" class="btn btn-primary" data-toggle="modal" data-target="#Confirm_modif">Modifier</button></td>';
                                echo '</tr>';
                            }
                            $response->closeCursor();
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ADMIN -->

        <div id="admin" class="hide">
            <center>
                <h3>Vous êtes dans le menu admin</h3>
            </center>
            </br>
            <div class="panel panel-danger">
                <div class="panel-heading">
                    <h3 class="panel-title">Mode administrateur</h3>
                </div>
                <div class="panel-body">
                    <table id="TabUser" class="display table table-hover">
                        <thead>
                            <tr>
                                <th class="active col-md-1">Id</th>
                                <th class="active col-md-2">Nom</th>
                                <th class="active col-md-2">Prénom</th>
                                <th class="active col-md-2">Identifiant</th>
                                <th class="active col-md-2">Rang</th>
                                <th class="active col-md-1">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                        require("Control/bdd.php");
                                        $req = "SELECT id_utilisateur, nom_utilisateur, prenom_utilisateur, identifiant_utilisateur, rang_utilisateur FROM utilisateur";
                                        $response = $bdd->query($req);
                                        while ($donnees = $response->fetch()) {
                                            echo '<tr>';
                                            echo '<td>'.$donnees["id_utilisateur"].'</td>';
                                            echo '<td>'.$donnees["nom_utilisateur"].'</td>';
                                            echo '<td>'.$donnees["prenom_utilisateur"].'</td>';
                                            echo '<td>'.$donnees["identifiant_utilisateur"].'</td>';
                                            echo '<td>'.$donnees["rang_utilisateur"].'</td>';
                                            echo '<td><button class="btn btn-primary">Modifier</button></td>';
                                            echo '</tr>';
                                        }
                                        $response->closeCursor();
                                    ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- MON COMPTE -->

        <div id="compte" class="hide">
            <form action="Control/account.php" method="post">
                <center>
                    <h3>
                        <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                        <b>Gestion du compte</b>
                    </h3>
                </center>
                <div style="padding: 40px;">
                    <center>
                        <h4>
                            <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Options générales</h4>
                    </center>
                    <hr>
                    <h4>
                        <span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Identifiant
                        <small>Ne peut pas être modifié.</small>
                    </h4>
                    <input disabled type="text" class="form-control" placeholder="<?php echo $unUser->getIdentifiant(); ?>">
                    </br>
                    <h4>
                        <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Nom</h4>
                    <input type="text" class="form-control" name="nom" value="<?php echo $unUser->getNom(); ?>">
                    </br>
                    <h4>
                        <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Prénom</h4>
                    <input type="text" class="form-control" name="prenom" value="<?php echo $unUser->getPrenom(); ?>">
                    </br>
                    <center>
                        <h4>
                            <span class="glyphicon glyphicon-lock" aria-hidden="true"></span> Modifier le mot de passe</h4>
                    </center>
                    <hr>
                    <h4>
                        <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Nouveau mot de passe</h4>
                    <input id="pwd1" type="password" class="form-control" placeholder="Rentrez un mot de passe">
                    </br>
                    <h4>
                        <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> Confirmer le mot de passe</h4>
                    <input id="pwd2" type="password" class="form-control" placeholder="Retapez votre mot de passe">
                    </br>
                    <script type="text/javascript">
                        function generer_password(champ_cible) {
                            var carac = 'azertyupqsdfghjkmwxcvbn0123456789AZERTYUPQSDFGHJKMWXCVBN&!?$*_-';
                            var pass = '';
                            longueur = 15;
                            for (i = 0; i < longueur; i++) {
                                var wpos = Math.round(Math.random() * carac.length);
                                pass += carac.substring(wpos, wpos + 1);
                            }
                            document.getElementById(champ_cible).value = pass;
                        }
                    </script>
                    <h4>
                        <span class="glyphicon glyphicon-lock" aria-hidden="true"></span> Générer un mot de passe aléatoire</h4>
                    <div class="form-inline">
                        <button type="button" class="btn btn-default" name="generer" onclick="javascript:generer_password('password');">Générer</button>
                        <input class="form-control" name="password" placeholder='Cliquez sur "Générer"' id="password" type="text" aria-describedby="generationmdp"
                        />
                        <small>À copier/coller dans "
                            <b>Nouveau mot de passe</b>".</small>
                    </div>
                    </br>
                    <hr>
                    <h4>
                        <span class="glyphicon glyphicon-lock" aria-hidden="true"></span> Mot de passe</h4>
                    <input required id="pwd" type="password" class="form-control" name="pwd" placeholder="Renseignez votre mot de passe pour autoriser le changement d'information(s)">
                    </br>
                    <center>
                        <input type="submit" class="btn btn-primary" value="Sauvegarder" />
                    </center>
                </div>
            </form>
        </div>

    </div>

    <!-- FOOTER -->
    </br>
    </br>
    </br>
    </br>
    <div class="footer">
        <div class="footer_contents">
            <div class="lFoot">
                <a href="https://creativecommons.org/licenses/by-nc-sa/3.0/fr/">
                    <img src="Include/Pic/cc.png" />
                </a>
                <a href="https://twitter.com/DANE_acLyon">
                    <img style="margin-left: 20px;" src="Include/Pic/twitter.svg" width="31" height="31" />
                </a>
            </div>
            <div class="rFoot">
                <a href="https://dane.ac-lyon.fr/spip/">DANE de Lyon</a>
                <b>|</b>
                <a href="mailto:nicolas.piegay@ac-lyon.fr?subject=[Créateur de QCM]">Nicolas Piegay</a>
            </div>
        </div>
    </div>
</body>

</html>