<img class="logohead" src="Include/Pic/logohead.png" width="100%" height=""/>
<div class="container">
    <div class="login-container">
        <div id="output"></div>
        <div class="form-box">
            <form action="Control/verif_login.php" method="post">
                <center><h2>Créateur de QCM</h2></center></br>
                <input name="identifiant" type="text" placeholder="identifiant" required>
                <input name="motdepasse" type="password" placeholder="mot de passe" required>
                <button class="btn btn-info btn-block login" type="submit">Connexion</button>
            </form>
        </div>
    </div>
</div>
