<?php
    try 
    {
        $bdd = new PDO('mysql:host=localhost;dbname=qcm', 'root', 'dane6904!');
    } catch (PDOException $e) 
    {
        print "Erreur !: " . $e->getMessage() . "<br/>";
        die();
    }
?>