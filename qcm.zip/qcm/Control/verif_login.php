<?php
    session_start();
    $pIdentifiant = $_POST["identifiant"];
    $pHash = md5($_POST["motdepasse"]);



    $inc = include("../Model/Cutilisateur.php");
    $unUser = new Cutilisateur(0);
    if (!$unUser) {
        echo "<b>[<span style='color:red'>ERREUR</span>]</b> Impossible d'instancier la classe <b>Cutilisateur.php</b></br>";
    } else {
        echo "<b>[<span style='color:green'>OK</span>]</b> La classe <b>Cutilisateur.php</b> a été instanciée</br>";
    }
    $unUser->login($pIdentifiant, $pHash);
    $idUser = $unUser->getId();
    if ($idUser == 0) {
        $_SESSION["Auth"] = false;
        header("Location: ../appli.php");
        exit();
    } else {
        $_SESSION["Auth"] = true;
        $_SESSION["Id"] = $idUser;
        header("Location: ../appli.php");
        exit();
    }
?>