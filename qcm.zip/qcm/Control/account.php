<?php
    require("bdd.php");
    session_start();
    $identifiant = "";
    $nom = $_POST["nom"];
    $prenom = $_POST["prenom"];
    $hpwd1 = md5($_POST["pwd1"]);
    $hpwd2 = md5($_POST["pwd2"]);
    $hpwd = md5($_POST["pwd"]);
    $ahpwd = "";

    $req = "SELECT mdp_utilisateur, nom_utilisateur, prenom_utilisateur FROM utilisateur WHERE id_utilisateur = " . $_SESSION["Id"];
    $response = $bdd->query($req);
    while ($donnees = $response->fetch()) {
        $ahpwd = $donnees["mdp_utilisateur"];
        if ($nom == "") {
            $nom = $donnees["nom_utilisateur"];
        }
        if ($prenom == "") {
            $prenom = $donnees["prenom_utilisateur"];
        }
    }
    $response->closeCursor();

    if ($ahpwd == $hpwd) {
        $identifiant = $prenom.".".$nom;
        $req = "UPDATE utilisateur SET nom_utilisateur='".$nom."',prenom_utilisateur='".$prenom."',identifiant_utilisateur='".$identifiant."' WHERE id_utilisateur = " . $_SESSION["Id"];
        $response = $bdd->query($req);
        echo "<script>alert('Votre compte a été mis à jour.');</script>";
        echo '<meta http-equiv="refresh" content="0;URL=../index.php">';
        exit();
    }
    else
    {
        echo "Erreur dans votre mot de passe";
    }
