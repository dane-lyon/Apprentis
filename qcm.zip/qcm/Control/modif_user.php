<?php
    $id_user = $_POST["id_user"];
    $unUser22 = new Cutilisateur($id_user);
?>

<div id="compte" class="hide">
    <form action="Control/accountVadmin.php" method="post">
        <center>
            <h3>
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                <b>Gestion du compte</b>
            </h3>
        </center>
        <div style="padding: 40px;">
            <center>
                <h4>
                    <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Options générales</h4>
            </center>
            <hr>
            <h4>
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span> Identifiant
                <small>Ne peut pas être modifié.</small>
            </h4>
            <input disabled type="text" class="form-control" placeholder="<?php echo $unUser2->getIdentifiant(); ?>">
            </br>
            <h4>
                <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Nom</h4>
            <input type="text" class="form-control" name="nom" value="<?php echo $unUser2->getNom(); ?>">
            </br>
            <h4>
                <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Prénom</h4>
            <input type="text" class="form-control" name="prenom" value="<?php echo $unUser2->getPrenom(); ?>">
            </br>
            <center>
                <h4>
                    <span class="glyphicon glyphicon-lock" aria-hidden="true"></span> Modifier le mot de passe</h4>
            </center>
            <hr>
            <h4>
                <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Nouveau mot de passe</h4>
            <input id="pwd1" type="password" class="form-control" placeholder="Rentrez un mot de passe">
            </br>
            <h4>
                <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> Confirmer le mot de passe</h4>
            <input id="pwd2" type="password" class="form-control" placeholder="Retapez votre mot de passe">
            </br>
            <script type="text/javascript">
                function generer_password(champ_cible) {
                    var carac = 'azertyupqsdfghjkmwxcvbn0123456789AZERTYUPQSDFGHJKMWXCVBN&!?$*_-';
                    var pass = '';
                    longueur = 15;
                    for (i = 0; i < longueur; i++) {
                        var wpos = Math.round(Math.random() * carac.length);
                        pass += carac.substring(wpos, wpos + 1);
                    }
                    document.getElementById(champ_cible).value = pass;
                }
            </script>
            <h4>
                <span class="glyphicon glyphicon-lock" aria-hidden="true"></span> Générer un mot de passe aléatoire</h4>
            <div class="form-inline">
                <button type="button" class="btn btn-default" name="generer" onclick="javascript:generer_password('password');">Générer</button>
                <input class="form-control" name="password" placeholder='Cliquez sur "Générer"' id="password" type="text" aria-describedby="generationmdp"
                />
                <small>À copier/coller dans "
                    <b>Nouveau mot de passe</b>".</small>
            </div>
            </br>
            <hr>
            <h4>
                <span class="glyphicon glyphicon-lock" aria-hidden="true"></span> Mot de passe</h4>
            <input required id="pwd" type="password" class="form-control" name="pwd" placeholder="Renseignez votre mot de passe pour autoriser le changement d'information(s)">
            </br>
            <center>
                <input type="submit" class="btn btn-primary" value="Sauvegarder" />
            </center>
        </div>
    </form>
</div>