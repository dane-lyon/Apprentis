<?php
    session_start();
    $_SESSION["Auth"] = false;
    session_destroy();
    header("Location: ../appli.php");
    exit();
?>