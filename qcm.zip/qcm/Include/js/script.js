var CompteurBoxP = 0;
var CompteurBoxQ = 0;
var CompteurBoxR = 0;
var Profil = [];
var Question = [];
var Reponse = [];
function CreateBox(pNom, pDiv) {
    if (pNom == "Profil") {
        CompteurBoxP = CompteurBoxP + 1;
        maDiv = document.createElement("div");
        maDiv.id = pNom + CompteurBoxP;
        maDiv.innerHTML = '<div class="form-group form-inline"><label>' + pNom +
            ' :</label> <div style="float: right;"><input style="width: 80%;" type="text" id="q' + CompteurBoxP +
            '" class="form-control" placeholder="Libellé..."> <button class="btn btn-danger" onclick="suppr(\'' + pDiv + '\',\'' +
            pNom + '\',\'' + CompteurBoxP +
            '\')"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button></div></div>';
        document.getElementById(pDiv).appendChild(maDiv);
    }
    if (pNom == "Question") {
        CompteurBoxQ = CompteurBoxQ + 1;
        maDiv = document.createElement("div");
        maDiv.id = pNom + CompteurBoxQ;
        maDiv.innerHTML = '<div class="form-group form-inline"><label>' + pNom +
            ' :</label> <div style="float: right;"><input style="width: 80%;" type="text" id="q' + CompteurBoxQ +
            '" class="form-control" placeholder="Libellé..."> <button class="btn btn-danger" onclick="suppr(\'' + pDiv + '\',\'' +
            pNom + '\',\'' + CompteurBoxQ +
            '\')"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button></div></div>';
        document.getElementById(pDiv).appendChild(maDiv);
    }
    if (pNom == "Réponse") {
        CompteurBoxR = CompteurBoxR + 1;
        maDiv = document.createElement("div");
        maDiv.id = pNom + CompteurBoxR;
        maDiv.innerHTML = '<div class="form-group form-inline"><label>' + pNom +
            ' :</label> <select id="QtoR' + CompteurBoxR + '"></select> <input type="text" id="q' + CompteurBoxR +
            '" class="form-control" placeholder="Libellé..."> <button class="btn btn-danger" onclick="suppr(\'' + pDiv + '\',\'' +
            pNom + '\',\'' + CompteurBoxR +
            '\')"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button></div>';
        document.getElementById(pDiv).appendChild(maDiv);
        injectionQ("QtoR"+CompteurBoxR);
    }
};

function suppr(pParent, pNom, pId) {
    if (pNom == "Profil") {
        CompteurBoxP = CompteurBoxP - 1;
        var obj = document.getElementById(pParent);
        var monInput = document.getElementById(pNom + pId);
        obj.removeChild(monInput);
    }
    if (pNom == "Question") {
        CompteurBoxQ = CompteurBoxQ - 1;
        var obj = document.getElementById(pParent);
        var monInput = document.getElementById(pNom + pId);
        obj.removeChild(monInput);
    }
    if (pNom == "Réponse") {
        CompteurBoxR = CompteurBoxR - 1;
        var obj = document.getElementById(pParent);
        var monInput = document.getElementById(pNom + pId);
        obj.removeChild(monInput);
    }
}

function tooglePart(pPart) {
    if (pPart == "suivant") {
        document.getElementById("sPart").classList.remove("hide");
        document.getElementById("fPart").classList.add("hide");
        BuildData();
    }
    if (pPart == "precedent") {
        document.getElementById("sPart").classList.add("hide");
        document.getElementById("fPart").classList.remove("hide");
        clearAll();
    }
}

function BuildData() {
    //Build Question
    for (var i = 0; i < CompteurBoxQ + 1; i++) {
        if (document.getElementById("q" + i).value != "") {
            Question.push(document.getElementById("q" + i).value);
        }
    }
    injectionQ("QtoR0");
}

function injectionQ(pId) {
    var select = document.getElementById(pId);
    for (var i = 0; i < Question.length + 1; i++) {
        select.options[select.options.length] = new Option(document.getElementById("q" + i).value, 'x');
    }
}

function clearAll()
{
    var oSelect = document.getElementById('QtoR0'),
    opts = oSelect.getElementsByTagName('option');
    while(opts[0]) {
        oSelect.removeChild(opts[0]);
    }
    Profil.length = 0;
    Question.length = 0;
    Reponse.length = 0;
}

/*function addQtoR(pRef) {
    var select = document.getElementById(pRef);
    Question.length = 0;
    for (var i = 0; i < CompteurBoxQ + 1; i++) {
        Question.push(document.getElementById("q" + i).value);
    }
    for (var i = 0; i < CompteurBoxQ + 1; i++) {
        select.options.remove(i);
    }
    Question.forEach(function (element) {
        select.options[select.options.length] = new Option(element, 'x');
    });
}*/

$(document).ready(function () {
    $('#TabQcm').DataTable(
        {
            language:
            {
                url: "Plugin/DataTables/media/French.json"
            }
        });
});

$(document).ready(function () {
    $('#TabUser').DataTable(
        {
            language:
            {
                url: "Plugin/DataTables/media/French.json"
            }
        });
});

function navigation(pToken, pToken2) {
    if (pToken2 == "btn_accueil") {
        pToken.classList.add("active");
        document.getElementById("btn_creer").classList.remove("active");
        document.getElementById("btn_gerer").classList.remove("active");
        document.getElementById("accueil").classList.remove("hide");
        document.getElementById("creer").classList.add("hide");
        document.getElementById("gerer").classList.add("hide");
        document.getElementById("admin").classList.add("hide");
        document.getElementById("compte").classList.add("hide");
    }
    if (pToken2 == "btn_creer") {
        pToken.classList.add("active");
        document.getElementById("btn_accueil").classList.remove("active");
        document.getElementById("btn_gerer").classList.remove("active");
        document.getElementById("accueil").classList.add("hide");
        document.getElementById("creer").classList.remove("hide");
        document.getElementById("gerer").classList.add("hide");
        document.getElementById("admin").classList.add("hide");
        document.getElementById("compte").classList.add("hide");
    }
    if (pToken2 == "btn_gerer") {
        pToken.classList.add("active");
        document.getElementById("btn_creer").classList.remove("active");
        document.getElementById("btn_accueil").classList.remove("active");
        document.getElementById("accueil").classList.add("hide");
        document.getElementById("creer").classList.add("hide");
        document.getElementById("gerer").classList.remove("hide");
        document.getElementById("admin").classList.add("hide");
        document.getElementById("compte").classList.add("hide");
    }
    if (pToken2 == "admin") {
        document.getElementById("btn_creer").classList.remove("active");
        document.getElementById("btn_accueil").classList.remove("active");
        document.getElementById("btn_gerer").classList.remove("active");
        document.getElementById("accueil").classList.add("hide");
        document.getElementById("creer").classList.add("hide");
        document.getElementById("gerer").classList.add("hide");
        document.getElementById("admin").classList.remove("hide");
        document.getElementById("compte").classList.add("hide");
    }
    if (pToken2 == "compte") {
        document.getElementById("btn_creer").classList.remove("active");
        document.getElementById("btn_accueil").classList.remove("active");
        document.getElementById("btn_gerer").classList.remove("active");
        document.getElementById("accueil").classList.add("hide");
        document.getElementById("creer").classList.add("hide");
        document.getElementById("gerer").classList.add("hide");
        document.getElementById("admin").classList.add("hide");
        document.getElementById("compte").classList.remove("hide");
    }
}