<?php 
    class Cutilisateur
    {
        private $id_utilisateur;
        private $nom_utilisateur;
        private $prenom_utilisateur;
        private $identifiant_utilisateur;
        private $rang_utilisateur;

        public function __construct($Token)
        {
            if ($Token != 0) {
                $pId = $Token;
                $this->id_utilisateur = $pId;
                $this->buildUser();
                //echo "<b>[<span style='color:green'>OK</span>]</b> Utilisateur initialisé</br>";
            }
        }

        public function login($pIdentifiant, $pHash)
        {
            require("bdd.php");
            $req = "SELECT id_utilisateur, identifiant_utilisateur, mdp_utilisateur FROM utilisateur";
            $response = $bdd->query($req);
            while ($donnees = $response->fetch()) {
                if ($pIdentifiant == $donnees['identifiant_utilisateur'] && $pHash == $donnees['mdp_utilisateur']) {
                    $this->id_utilisateur = $donnees["id_utilisateur"];
                }
            }
            $response->closeCursor();
        }

        public function buildUser()
        {
            $pId = $this->id_utilisateur;
            require("./Control/bdd.php");
            $req = "SELECT nom_utilisateur, prenom_utilisateur, identifiant_utilisateur, rang_utilisateur FROM utilisateur WHERE id_utilisateur = " . $pId;
            $response = $bdd->query($req);
            while ($donnees = $response->fetch()) {
                $this->nom_utilisateur = $donnees["nom_utilisateur"];
                $this->prenom_utilisateur = $donnees["prenom_utilisateur"];
                $this->identifiant_utilisateur = $donnees["identifiant_utilisateur"];
                $this->rang_utilisateur = $donnees["rang_utilisateur"];
            }
            $response->closeCursor();
        }

        public function ChgPwd($pNewHash)
        {
            require("./Control/bdd.php");
            $req = "UPDATE utilisateur SET mdp_utilisateur = " . $pNewHash . "WHERE id_utilisateur = " . $this->id_utilisateur;
            $response = $bdd->query($req);
        }

        public function pushDump()
        {
            $id = $this->id_utilisateur;
            $nom = $this->nom_utilisateur;
            $prenom = $this->prenom_utilisateur;
            $identifiant = $this->prenom_utilisateur.".".$this->nom_utilisateur;
            $rang = $this->rang_utilisateur;

            $req = "UPDATE utilisateur SET nom_utilisateur=".$nom.",prenom_utilisateur=".$prenom.",identifiant_utilisateur=".$identifiant.", WHERE id_utilisateur = ".$id;
            require("./Control/bdd.php");
            $bdd->query($req);
        }

        public function setId($pId)
        {
            $this->id_utilisateur = $pId;
        }

        public function getId()
        {
            return $this->id_utilisateur;
        }

        public function setNom($pNom)
        {
            $this->nom_utilisateur = $pNom;
        }

        public function getNom()
        {
            return $this->nom_utilisateur;
        }

        public function setPrenom($pPrenom)
        {
            $this->prenom_utilisateur = $pPrenom;
        }

        public function getPrenom()
        {
            return $this->prenom_utilisateur;
        }

        public function setIdentifiant($pIdentifiant)
        {
            $this->identifiant_utilisateur = $pIdentifiant;
        }

        public function getIdentifiant()
        {
            return $this->identifiant_utilisateur;
        }

        public function setRang($pRang)
        {
            $this->rang_utilisateur = $pRang;
        }

        public function getRang()
        {
            return $this->rang_utilisateur;
        }
    }
