<?php 
    require("Cquestion.php");
    require("Cprofil.php");
    require("Creponse.php");

    class Cqcm
    {
        private $id_qcm;
        private $nom_qcm;
        private $question = array();
        private $profil = array();
        private $reponse = array();

        public function __construct($pId)
        {
            // BUILD QCM
            require("Control/bdd.php");
            $req = "SELECT nom_qcm FROM QCM WHERE id_qcm = " . $pId;
            $response = $bdd->query($req);
            while ($donnees = $response->fetch()) {
                $this->id_qcm = $pId;
                $this->nom_qcm = $donnees["nom_qcm"];
            }
            $response->closeCursor();
            
            //BUILD QUESTION
            $i = 0;
            require("Control/bdd.php");
            $req = "SELECT id_question, ref_qcm, lib_question FROM QUESTION WHERE ref_qcm = " . $this->id_qcm;
            $response = $bdd->query($req);
            while ($donnees = $response->fetch()) {
                $this->question[$i] = new Cquestion($donnees["id_question"], $donnees["ref_qcm"], $donnees["lib_question"]);
                $i = $i + 1;
            }
            $response->closeCursor();
 
            //BUILD PROFIL
            $j = 0;
            require("Control/bdd.php");
            $req = "SELECT id_profil, ref_qcm, nom_profil FROM PROFIL WHERE ref_qcm = " . $this->id_qcm;
            $response = $bdd->query($req);
            while ($donnees = $response->fetch()) {
                $this->profil[$j] = new Cprofil($donnees["id_profil"], $donnees["ref_qcm"], $donnees["nom_profil"]);
                $j = $j + 1;
            }
            $response->closeCursor();

            //BUILD REPONSE
            $k = 0;
            require("Control/bdd.php");
            foreach ($this->question as $Num) {
                $req = "SELECT id_reponse, ref_question, lib_reponse, poids_reponse, ref_profil FROM REPONSE WHERE ref_question = " . $Num->getId();
                $response = $bdd->query($req);
                while ($donnees = $response->fetch()) {
                    $this->reponse[$k] = new Creponse($donnees["id_reponse"], $donnees["ref_question"], $donnees["lib_reponse"], $donnees["poids_reponse"], $donnees["ref_profil"]);
                    $k = $k + 1;
                }
                $response->closeCursor();
            }
        }

        public function setNom($pNom)
        {
            $this->nom_qcm = $pNom;
        }

        public function getNom()
        {
            return $this->nom_qcm;
        }
    }
?>