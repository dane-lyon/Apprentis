<?php 
    class Cquestion
    {
        private $id_question;
        private $ref_qcm;
        private $lib_question;

        public function __construct($pId, $pRef, $pLib)
        {  
            $this->id_question = $pId;
            $this->ref_qcm = $pRef;
            $this->lib_question = $pLib;
        }

        public function setId($pId)
        {
            $this->id_question = $pId;
        }

        public function getId()
        {
            return $this->id_question;
        }

        public function setRef($pRef)
        {
            $this->ref_qcm = $pRef;
        }

        public function getRef()
        {
            return $this->ref_qcm;
        }

        public function setLib($pNom)
        {
            $this->lib_question = $pNom;
        }

        public function getLib()
        {
            return $this->lib_question;
        }
    }
