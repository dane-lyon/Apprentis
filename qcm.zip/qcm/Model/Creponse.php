<?php 
    class Creponse
    {
        private $id_reponse;
        private $ref_question;
        private $lib_reponse;
        private $poids_reponse;
        private $ref_profil;

        public function __construct($pId, $pRefQ, $pLib, $pPoids, $pRefP)
        {  
            $this->id_reponse = $pId;
            $this->ref_question = $pRefQ;
            $this->lib_reponse = $pLib;
            $this->poids_reponse = $pPoids;
            $this->ref_profil = $pRefP;
        }

        public function setId($pId)
        {
            $this->id_reponse = $pId;
        }

        public function getId()
        {
            return $this->id_reponse;
        }

        public function setRefQ($pRef)
        {
            $this->ref_question = $pRef;
        }

        public function getRefQ()
        {
            return $this->ref_question;
        }

        public function setLib($pLib)
        {
            $this->lib_reponse = $pLib;
        }

        public function getLib()
        {
            return $this->lib_reponse;
        }

        public function setPoids($pPoids)
        {
            $this->poids_reponse = $pPoids;
        }

        public function getPoids()
        {
            return $this->poids_reponse;
        }

        public function setRefP($pRef)
        {
            $this->ref_profil = $pRef;
        }

        public function getRefP()
        {
            return $this->ref_profil;
        }
    }
