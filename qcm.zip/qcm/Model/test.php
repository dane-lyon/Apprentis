<?php
    require("Cqcm.php");
    $unQcm = new Cqcm(1);
?>