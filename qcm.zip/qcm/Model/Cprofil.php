<?php 
    class Cprofil
    {
        private $id_profil;
        private $ref_qcm;
        private $nom_profil;

        public function __construct($pId, $pRef, $pNom)
        {  
            $this->id_profil = $pId;
            $this->ref_qcm = $pRef;
            $this->nom_profil = $pNom;
        }

        public function setId($pId)
        {
            $this->id_profil = $pId;
        }

        public function getId()
        {
            return $this->id_profil;
        }

        public function setRef($pRef)
        {
            $this->ref_qcm = $pRef;
        }

        public function getRef()
        {
            return $this->ref_qcm;
        }

        public function setNom($pNom)
        {
            $this->nom_profil = $pNom;
        }

        public function getNom()
        {
            return $this->nom_profil;
        }
    }
