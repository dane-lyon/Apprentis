<?php
ini_set('display_errors','on');
error_reporting(E_ALL);
session_start();
header("content-type:text/html; charset=UTF-8");
?>

<!-- défini le style pour toutes les pages (accès CSS - Bootstrap - Images - caractères utf-8, etc...) -->
<head>
      <!-- icone du favicon -->
      <link rel="icon" type="image/png" href="Model/Images/logo.png">
      <!-- Titre de la page web -->
      <title>Site académique</title>

      <!-- Latest compiled and minified CSS -->
      <link rel="stylesheet" href="Model/Bootstrap/css/bootstrap.css">

      <!-- Latest compiled and minified JavaScript -->
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"
        integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa"
        crossorigin="anonymous"></script>

      <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

      <!-- Type de caractères -->
      <meta charset="utf-8"/>
      <!-- Accede au fiche de style CSS -->
      <link rel="stylesheet" href="Model/css/style.css">
      <link rel="stylesheet" type="text/css" href="Model/DataTables/media/css/jquery.dataTables.min.css">
      <!-- Accede au fiche de Java Script -->
      <script type="text/javascript" src="Model/js/jquery.js"></script>
      <script type="text/javascript" src="Model/js/bootstrap.js"></script>
      <script type="text/javascript" src="Model/js/script.js"></script>
      <script type="text/javascript" src="Model/DataTables/media/js/jquery.js"></script>
      <script type="text/javascript" src="Model/DataTables/media/js/jquery.dataTables.min.js"></script>
      <script type="text/javascript" src="Model/js/tableau.js"></script>
</head>
