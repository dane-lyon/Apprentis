<?php
require_once 'DAO.php';
$dao = new DAO();
// Les nouvels id pour chaque table
$id_etab = $dao->new_id("id_etab", "etablissement");
$id_site = $dao->new_id("id_site", "site");
$id_demande_crea = $dao->new_id("id_demande", "demande_creation");
$id_migration = $dao->new_id("id_migration", "migration");
$id_bdd = $dao->new_id("id_bdd", "bdd_site");
$id_dir_pub = $dao->new_id("id_dir_publication", "dir_publication");
$id_courrier_dir_pub = $dao->new_id("id_courrier_dir_pub", "courrier_dir_publication");
$id_web = $dao->new_id("id_webmestre", "webmestre");
$id_courrier_web = $dao->new_id("id_courrier_web", "courrier_webmestre");
// Les informations pour la création d'un nouvel établisement
$rne_etab = $_POST['rne_etab'];
$type_etab = $_POST['type_etab'];
$nom_etab = $_POST['nom_etab'];
$com_etab = $_POST['commune_etab'];
$coll_etab = $_POST['col_etab'];
// Les informations pour la création d'un nouveau site
$url_pub = $_POST['url_publique'];
$url_pri = $_POST['url_privee'];
$proto_site = $_POST['protocole_site'];
$hote_site = $_POST['hote_site'];
$port_site = $_POST['port_site'];
$id_hote_site = $_POST['id_hote_site'];
$mdp_hote_site = $_POST['mdp_hote_site'];
// Les informations pour la création d'une demande de création
$num_serv_crea = $_POST['num_serv_crea'];
$date_demande_crea = $_POST['date_demande_crea'];
$date_reso_crea = $_POST['date_reso_crea'];
$nom_rapport_crea = $_POST['nom_rapport_crea'];
$upload_rapport_crea = $_POST['upload_rapport_crea'];
// Les informations pour la création d'une migration
$num_service_mig = $_POST['num_service_mig'];
$date_demande_mig = $_POST['date_demande_mig'];
$date_mig = $_POST['date_mig'];
$aut_mig = $_POST['aut_mig'];
$version_spip = $_POST['version_spip'];
$version_escal = $_POST['version_escal'];
// Les informations pour la création d'un BDD
$nom_bdd = $_POST['nom_bdd'];
$user_bdd = $_POST['user_bdd'];
$pwd_bdd = $_POST['pwd_bdd'];
// Les informations pour la création d'un directeur de publication
$nom_dir_pub = $_POST['nom_dir_pub'];
$prenom_dir_pub = $_POST['prenom_dir_pub'];
$fonction_dir_pub = $_POST['fonction_dir_pub'];
$mail_dir_pub = $_POST['mail_dir_pub'];
$civilite_dir_pub = $_POST['civilite_dir_pub'];
$identifiant_dir_pub = $_POST['identifiant_dir_pub'];
$pwd_dir_pub = $_POST['pwd_dir_pub'];
// les information pour la création d'un courrier pour le directeur de publication
$nom_courrier_dir_pub = $_POST['nom_courrier_dir_pub'];
$upd_courrier_dir_pub = $_POST['upd_courrier_dir_pub'];

// Les informations pour la création d'un directeur de publication
$nom_web = $_POST['nom_web'];
$prenom_web = $_POST['prenom_web'];
$fonction_web = $_POST['fonction_web'];
$mail_web = $_POST['mail_web'];
$civilite_web = $_POST['civilite_web'];
$identifiant_web = $_POST['identifiant_web'];
$pwd_web = $_POST['pwd_web'];
// les information pour la création d'un courrier pour le directeur de publication
$nom_courrier_web = $_POST['nom_courrier_web'];
$upd_courrier_web = $_POST['upd_courrier_web'];


    

$table_etab = 'etablissement(id_etab,rne,type,nom_etab,commune,collectivite)';
$values_etab = '"'. $id_etab . '","' . $rne_etab . '","' . $type_etab . '","' . $nom_etab . '","' . $com_etab . '","' . $coll_etab . '"';

$table_site = 'site(id_site,id_etab,url_publique,url_privee,protocole,hote,port,id_hote,mdp_hote)';
$values_site = '"'. $id_site . '","' . $id_etab . '","' . $url_pub . '","' . $url_pri . '","' . $proto_site . '","' . $hote_site . '","' . $port_site . '","' . $id_hote_site . '","' . $mdp_hote_site . '"';

$table_demande_crea = 'demande_creation(id_demande,id_site,num_service_ev_dc,date_demande_dc,date_resolu_dc,nom_rapport_dc,upload_rapport_dc)';
$values_demande_crea = '"'. $id_demande_crea . '","' . $id_site . '","' . $num_serv_crea . '","' . $date_demande_crea . '","' . $date_reso_crea . '","' . $nom_rapport_crea . '","' . $upload_rapport_crea . '"';

$table_migration = 'migration(id_migration,id_site,num_service_ev_m,date_demande_m,date_migration_m,auteur_migration_m,version_spip_m,version_escal_m)';
$values_migration = '"'. $id_migration . '","' . $id_site . '","' . $num_service_mig . '","' . $date_demande_mig . '","' . $date_mig . '","' . $aut_mig . '","' . $version_spip . '","' . $version_escal . '"';

$table_bdd = 'bdd_site(id_bdd,id_site,nom_bdd,utilisateur_bdd,mdp_bdd)';
$values_bdd = '"'. $id_bdd . '","' . $id_site . '","' . $nom_bdd . '","' . $user_bdd . '","' . $pwd_bdd . '"';

$table_dir_pub = 'dir_publication(id_dir_publication,id_etab,nom_dp,prenom_dp,fonction_dp,mail_dp,civilite_dp,identifiant_dp,mdp_dp)';
$values_dir_pub = '"'. $id_dir_pub . '","' . $id_etab . '","' . $nom_dir_pub . '","' . $prenom_dir_pub . '","' . $fonction_dir_pub . '","' . $mail_dir_pub . '","' . $civilite_dir_pub . '","' . $identifiant_dir_pub . '","' . $pwd_dir_pub . '"';

$table_courrier_dir_pub = 'courrier_dir_publication(id_courrier_dir_pub,id_dir_publication,nom_courrier_dir_pub,upload_courrier_dir_pub)';
$values_courrier_dir_pub = '"'. $id_courrier_dir_pub . '","' . $id_dir_pub . '","' . $nom_courrier_dir_pub . '","' . $upd_courrier_dir_pub . '"';

$table_web = 'webmestre(id_webmestre,id_etab,nom_web,prenom_web,fonction_web,mail_web,civilite_web,identifiant_web,mdp_web)';
$values_web = '"'. $id_web . '","' . $id_etab . '","' . $nom_web . '","' . $prenom_web . '","' . $fonction_web . '","' . $mail_web . '","' . $civilite_web . '","' . $identifiant_web . '","' . $pwd_web . '"';

$table_courrier_web = 'courrier_webmestre(id_courrier_web,id_webmestre,nom_courrier_web,upload_courrier_web)';
$values_courrier_web = '"'. $id_courrier_web . '","' . $id_web . '","' . $nom_courrier_web . '","' . $upd_courrier_web . '"';






$dao = new DAO();
$dao->create($table_etab, $values_etab);
$dao->create($table_site, $values_site);
$dao->create($table_demande_crea, $values_demande_crea);
$dao->create($table_migration, $values_migration);
$dao->create($table_bdd, $values_bdd);
$dao->create($table_dir_pub, $values_dir_pub);
$dao->create($table_courrier_dir_pub, $values_courrier_dir_pub);
$dao->create($table_web, $values_web);
$dao->create($table_courrier_web, $values_courrier_web);


?>
<script LANGUAGE="JavaScript"> alert("Le site a bien été créé"); </script>
<meta http-equiv="refresh" content="0; URL=../index.php?redirect=etab_table"/>
<?php

?>