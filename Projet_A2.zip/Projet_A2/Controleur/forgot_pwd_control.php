<?php
session_start();

    $email = $_POST['email'];

    if(isset($email))
	{ 
		$destinataire = $email;
		$sujet = "sujet";
		$message = "ton contenu avec style à l'intérieur des balises";
		$headers = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";

		mail($destinataire, $sujet, $message, $headers);

		?>
			<script LANGUAGE="JavaScript">
				document.location.href="../index.php"
			</script>
		<?php
	} 
	else
	{
		$_SESSION["auth"] = false;
		?>
			<script LANGUAGE="JavaScript"> alert("Identifiants incorrects"); </script>
			<meta http-equiv="refresh" content="0; URL=../index.php"/>
		<?php
    }

?>