<?php
session_start();
require_once 'DAO.php';
	
	$_SESSION['username'] = $_POST['username'];
	$password = $_POST['password'];
	$salt = 'projetdanea2';
	$pwdsecure = md5($password.$salt);
	require_once 'DAO.php';

	$dao = new DAO();
	$bdd = $dao->connectionBDD();
	$request = "SELECT nom, prenom, username, password FROM users";
	$request = $bdd->prepare("SELECT id_user,nom, prenom, username, password FROM users");
	$request->execute();
	$response = $request;
	unset($bdd);
	//$response = $bdd->query($request);

	
	while($donnees = $response->fetch())
	{
		
		if($_SESSION['username'] == $donnees['username'] && $pwdsecure == $donnees['password'])
		{
			$_SESSION['auth'] = true;
			$_SESSION['nomPrenom'] = $donnees['prenom'].' '.$donnees['nom'];
			$_SESSION['id_user'] =  $donnees['id_user'];
		}
	}
	
	$response->closeCursor();
	if($_SESSION["auth"] == true)
	{ 
		?>
			<script LANGUAGE="JavaScript">
				document.location.href="../index.php"
			</script>
		<?php
	} 
	else
	{
		$_SESSION["auth"] = false;
		?>
			<script LANGUAGE="JavaScript"> alert("Identifiants ou mot de passe incorrects"); </script>
			<meta http-equiv="refresh" content="0; URL=../index.php"/>
		<?php
    }
?>