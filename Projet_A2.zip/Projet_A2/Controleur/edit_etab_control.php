<?php
session_start();
require_once "DAO.php";

// Les informations pour la création d'un nouvel établisement
$rne_etab = $_POST['rne_etab'];
$type_etab = $_POST['type_etab'];
$nom_etab = $_POST['nom_etab'];
$com_etab = $_POST['commune_etab'];
$coll_etab = $_POST['col_etab'];
// Les informations pour la création d'un nouveau site
$url_pub = $_POST['url_publique'];
$url_pri = $_POST['url_privee'];
$proto_site = $_POST['protocole_site'];
$hote_site = $_POST['hote_site'];
$port_site = $_POST['port_site'];
$id_hote_site = $_POST['id_hote_site'];
$mdp_hote_site = $_POST['mdp_hote_site'];
// Les informations pour la création d'une demande de création
$num_serv_crea = $_POST['num_serv_crea'];
$date_demande_crea = $_POST['date_demande_crea'];
$date_reso_crea = $_POST['date_reso_crea'];
$nom_rapport_crea = $_POST['nom_rapport_crea'];
$upload_rapport_crea = $_POST['upload_rapport_crea'];
// Les informations pour la création d'une migration
$num_service_mig = $_POST['num_service_mig'];
$date_demande_mig = $_POST['date_demande_mig'];
$date_mig = $_POST['date_mig'];
$aut_mig = $_POST['aut_mig'];
$version_spip = $_POST['version_spip'];
$version_escal = $_POST['version_escal'];
// Les informations pour la création d'un BDD
$nom_bdd = $_POST['nom_bdd'];
$user_bdd = $_POST['user_bdd'];
$pwd_bdd = $_POST['pwd_bdd'];
// Les informations pour la création d'un directeur de publication
$nom_dir_pub = $_POST['nom_dir_pub'];
$prenom_dir_pub = $_POST['prenom_dir_pub'];
$fonction_dir_pub = $_POST['fonction_dir_pub'];
$mail_dir_pub = $_POST['mail_dir_pub'];
$civilite_dir_pub = $_POST['civilite_dir_pub'];
$identifiant_dir_pub = $_POST['identifiant_dir_pub'];
$pwd_dir_pub = $_POST['pwd_dir_pub'];
// les information pour la création d'un courrier pour le directeur de publication
$nom_courrier_dir_pub = $_POST['nom_courrier_dir_pub'];
$upd_courrier_dir_pub = $_POST['upd_courrier_dir_pub'];

// Les informations pour la création d'un directeur de publication
$nom_web = $_POST['nom_web'];
$prenom_web = $_POST['prenom_web'];
$fonction_web = $_POST['fonction_web'];
$mail_web = $_POST['mail_web'];
$civilite_web = $_POST['civilite_web'];
$identifiant_web = $_POST['identifiant_web'];
$pwd_web = $_POST['pwd_web'];
// les information pour la création d'un courrier pour le directeur de publication
$nom_courrier_web = $_POST['nom_courrier_web'];
$upd_courrier_web = $_POST['upd_courrier_web'];


$dao = new DAO();
if(isset($_SESSION['id_etab'])){
    if($rne_etab != $_SESSION['rne_etab'] || $type_etab != $_SESSION['type_etab'] || $nom_etab != $_SESSION['nom_etab'] || $com_etab != $_SESSION['commune_etab'] || $coll_etab != $_SESSION['col_etab']){
        $query = "UPDATE etablissement
        SET rne =" . " '" . $rne_etab ."',". 
        "type =" .  " '" . $type_etab ."'," .
        "nom_etab =" .  " '" . $nom_etab ."'," .
        "commune =" .  " '" . $com_etab ."'," .
        "collectivite =" .  " '" . $coll_etab . " '" .
        " WHERE id_etab = " . $_SESSION['id_etab'] . ";";
        $dao->update($query);
    }
    if($url_pub != $_SESSION['url_publique'] || $url_pri != $_SESSION['url_privee'] || $proto_site != $_SESSION['protocole_site'] || $hote_site != $_SESSION['hote_site'] || $port_site != $_SESSION['port_site'] || $id_hote_site != $_SESSION['id_hote_site'] || $mdp_hote_site != $_SESSION['mdp_hote_site']){
        $query = "UPDATE site
        SET url_publique =" . " '" . $url_pub ."',". 
        "url_privee =" .  " '" . $url_pri ."'," .
        "protocole =" .  " '" . $proto_site ."'," .
        "hote =" .  " '" . $hote_site ."'," .
        "port =" .  " '" . $port_site . " '," .
        "id_hote =" .  " '" . $id_hote_site . " '," .
        "mdp_hote =" .  " '" . $mdp_hote_site . " '" .
        " WHERE id_site = " . $_SESSION['id_site'] . ";";
        $dao->update($query);
    }
    if($num_serv_crea != $_SESSION['num_serv_crea'] || $date_demande_crea != $_SESSION['date_demande_crea'] || $date_reso_crea != $_SESSION['date_reso_crea'] || $nom_rapport_crea != $_SESSION['nom_rapport_crea'] || $upload_rapport_crea != $_SESSION['upload_rapport_crea']){
        $query = "UPDATE demande_creation
        SET num_service_ev_dc =" . " '" . $num_serv_crea ."',". 
        "date_demande_dc =" .  " '" . $date_demande_crea ."'," .
        "date_resolu_dc =" .  " '" . $date_reso_crea ."'," .
        "nom_rapport_dc =" .  " '" . $nom_rapport_crea ."'," .
        "upload_rapport_dc =" .  " '" . $upload_rapport_crea . " '" .
        " WHERE id_site = " . $_SESSION['id_site'] . ";";
        $dao->update($query);
    }
    if($num_service_mig != $_SESSION['num_service_mig'] || $date_demande_mig != $_SESSION['date_demande_mig'] || $date_mig != $_SESSION['date_mig'] || $aut_mig != $_SESSION['aut_mig'] || $version_spip != $_SESSION['version_spip'] || $version_escal != $_SESSION['version_escal']){
        $query = "UPDATE migration
        SET num_service_ev_m =" . " '" . $num_service_mig ."',". 
        "date_demande_m =" .  " '" . $date_demande_mig ."'," .
        "date_migration_m =" .  " '" . $date_mig ."'," .
        "auteur_migration_m =" .  " '" . $aut_mig ."'," .
        "version_spip_m =" .  " '" . $version_spip ."'," .
        "version_escal_m =" .  " '" . $version_escal . " '" .
        " WHERE id_site = " . $_SESSION['id_site'] . ";";
        $dao->update($query);
    }
    if($nom_bdd != $_SESSION['nom_bdd'] || $user_bdd != $_SESSION['user_bdd'] || $pwd_bdd != $_SESSION['pwd_bdd']){
        $query = "UPDATE bdd_site
        SET nom_bdd =" . " '" . $nom_bdd ."',". 
        "utilisateur_bdd =" .  " '" . $user_bdd ."'," .
        "mdp_bdd =" .  " '" . $pwd_bdd . " '" .
        " WHERE id_site = " . $_SESSION['id_site'] . ";";
        $dao->update($query);
    }
    if($nom_dir_pub != $_SESSION['nom_dir_pub'] || $prenom_dir_pub != $_SESSION['prenom_dir_pub'] || $fonction_dir_pub != $_SESSION['fonction_dir_pub'] || $mail_dir_pub != $_SESSION['mail_dir_pub'] || $civilite_dir_pub != $_SESSION['civilite_dir_pub'] || $identifiant_dir_pub != $_SESSION['identifiant_dir_pub'] || $pwd_dir_pub != $_SESSION['pwd_dir_pub'] || $nom_courrier_dir_pub != $_SESSION['nom_courrier_dir_pub'] || $upd_courrier_dir_pub != $_SESSION['upd_courrier_dir_pub']){
        $query = "UPDATE dir_publication
        SET nom_dp =" . " '" . $nom_dir_pub ."',". 
        "prenom_dp =" .  " '" . $prenom_dir_pub ."'," .
        "fonction_dp =" .  " '" . $fonction_dir_pub ."'," .
        "mail_dp =" .  " '" . $mail_dir_pub ."'," .
        "civilite_dp =" .  " '" . $civilite_dir_pub ."'," .
        "identifiant_dp =" .  " '" . $identifiant_dir_pub ."'," .
        "mdp_dp =" .  " '" . $pwd_dir_pub . " '" .
        " WHERE id_etab = " . $_SESSION['id_etab'] . ";";
        $dao->update($query);
        $query = "UPDATE courrier_dir_publication
        SET nom_courrier_dir_pub =" . " '" . $nom_courrier_dir_pub ."',".
        "upload_courrier_dir_pub =" .  " '" . $upd_courrier_dir_pub . " '" .
        " WHERE id_dir_publication = " . $_SESSION['id_dir_publication'] . ";";
        $dao->update($query);

    }
    if($nom_web != $_SESSION['nom_web'] || $prenom_web != $_SESSION['prenom_web'] || $fonction_web != $_SESSION['fonction_web'] || $mail_web != $_SESSION['mail_web'] || $civilite_web != $_SESSION['civilite_web'] || $identifiant_web != $_SESSION['identifiant_web'] || $pwd_web != $_SESSION['pwd_web'] || $nom_courrier_web != $_SESSION['nom_courrier_web'] || $upd_courrier_web != $_SESSION['upd_courrier_web']){
        $query = "UPDATE webmestre
        SET nom_web =" . " '" . $nom_web ."',". 
        "prenom_web =" .  " '" . $prenom_web ."'," .
        "fonction_web =" .  " '" . $fonction_web ."'," .
        "mail_web =" .  " '" . $mail_web ."'," .
        "civilite_web =" .  " '" . $civilite_web ."'," .
        "identifiant_web =" .  " '" . $identifiant_web ."'," .
        "mdp_web =" .  " '" . $pwd_web . " '" .
        " WHERE id_etab = " . $_SESSION['id_etab'] . ";";
        $dao->update($query);
        $query = "UPDATE courrier_dir_publication
        SET nom_courrier_web =" . " '" . $nom_courrier_web ."',".
        "upload_courrier_web =" .  " '" . $upd_courrier_web . " '" .
        " WHERE id_dir_publication = " . $_SESSION['id_dir_publication'] . ";";
        $dao->update($query);
    }

    ?>
    <script LANGUAGE="JavaScript"> alert("Les informations ont bien été modifié'"); </script>
    <meta http-equiv="refresh" content="0; URL=../index.php?redirect=etab_table"/>
    <?php
}
else{
    ?>
    <script LANGUAGE="JavaScript"> alert("Les informations n'ont pas été modifié"); </script>
    <meta http-equiv="refresh" content="0; URL=../index.php?redirect=etab_table"/>
    <?php
}


?>