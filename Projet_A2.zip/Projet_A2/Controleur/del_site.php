<?php
require('DAO.php');

if(isset($_GET['id'])){
    
        $dao = new DAO();

        $request = "SELECT b.id_site, dc.id_site, m.id_site, s.id_site, 
        cdp.id_dir_publication, dp.id_dir_publication, 
        cw.id_webmestre, w.id_webmestre, 
        e.id_etab, w.id_etab, dp.id_etab, 
        cw.id_courrier_web, 
        cdp.id_courrier_dir_pub,
        b.id_bdd,
        m.id_migration,
        dc.id_demande
        FROM webmestre w, 
        courrier_dir_publication cdp, 
        courrier_webmestre cw, 
        demande_creation dc, 
        dir_publication dp, 
        migration m, 
        etablissement e, 
        site s, 
        bdd_site b
        WHERE e.id_etab =" . $_GET['id'] . "
        AND e.id_etab = s.id_etab
        AND e.id_etab = w.id_etab
        AND e.id_etab = dp.id_etab
        AND dp.id_dir_publication = cdp.id_dir_publication
        AND w.id_webmestre = cw.id_webmestre
        AND s.id_site = b.id_site
        AND s.id_site = dc.id_site
        AND s.id_site = m.id_site
        ;";
        $response = $dao->selectFromSQL($request);
        $data = $response->fetch();


        $table_courrier_web = "courrier_webmestre";
        $table_web = "webmestre";
        $table_courrier_dir_pub = "courrier_dir_publication";
        $table_dir_pub = "dir_publication";
        $table_bdd = "bdd_site";
        $table_migration = "migration";
        $table_demande_crea = "demande_creation";
        $table_site = "site";
        $table_etab = "etablissement";

        $condition_courrier_web = "id_courrier_web = " . $data["id_courrier_web"];
        $condition_web = "id_webmestre = " .  $data["id_webmestre"];
        $condition_courrier_dir_pub = "id_courrier_dir_pub = " .  $data["id_courrier_dir_pub"];
        $condition_dir_pub = "id_dir_publication = " .  $data["id_dir_publication"];
        $conditions_bdd = "id_bdd = " .  $data["id_bdd"];
        $condition_migration = "id_migration = " .  $data["id_migration"];
        $condition_demande_crea = "id_demande = " .  $data["id_demande"];
        $condition_site = "id_site = " .  $data["id_site"];
        $condition_etab = "id_etab = " .  $_GET['id'];

        $dao->delete($table_courrier_web, $condition_courrier_web);
        $dao->delete($table_web, $condition_web);
        $dao->delete($table_courrier_dir_pub, $condition_courrier_dir_pub);
        $dao->delete($table_dir_pub, $condition_dir_pub);
        $dao->delete($table_bdd, $conditions_bdd);
        $dao->delete($table_migration, $condition_migration);
        $dao->delete($table_demande_crea, $condition_demande_crea);
        $dao->delete($table_site, $condition_site);
        $dao->delete($table_etab, $condition_etab);

        echo '<script LANGUAGE="JavaScript"> alert("Le site a bien été supprimé"); </script>
        <meta http-equiv="refresh" content="0; URL=../index.php?redirect=etab_table"/>';

    }
    else{
        echo '<script LANGUAGE="JavaScript"> alert("Le site n\'a pas pu être supprimé "); </script>
        <meta http-equiv="refresh" content="0; URL=../index.php?redirect=etab_table"/>';
    }

?>