
<?php
class DAO
{
    function connectionBDD()
    {
        try {
            $bdd = new PDO('mysql:host=localhost;dbname=ProjetA2;charset=utf8', 'root', 'dane6904!', array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
        } catch (PDOException $e) {
            print "Erreur !: " . $e->getMessage() . "<br/>";
            die();
        } 
        return $bdd;
    }

    function new_id($id_name, $table_name)
    {
        $id_max = 0;
        $pdo = $this->connectionBDD();
        $request = $pdo->prepare("SELECT MAX(". $id_name .") FROM ". $table_name);
        $request->execute();
        $response = $request;
        while($donnees = $response->fetch())
        {
            $id_max = $donnees['MAX('. $id_name .')'] + 1;
        }
        unset($pdo);
        return $id_max;
    }

    function create($table, $values)
    {
        $pdo = $this->connectionBDD();
        $request = $pdo->prepare('INSERT INTO '. $table . ' VALUES ('. $values .') ;');
        $request->execute();
        unset($pdo);
    }
    
    function update($query)
    {
        $pdo = $this->connectionBDD();
        $request = $pdo->prepare($query);
        $request->execute();
        unset($pdo);
    }

    function delete($table, $condition)
    {
        $pdo = $this->connectionBDD();
        $request = $pdo->prepare('DELETE FROM '. $table . ' WHERE ' . $condition . " ;");
        $request->execute();
        unset($pdo);
    }

    function selectFromSQL($request)
    {
        $pdo = $this->connectionBDD();
        $request = $pdo->prepare($request);
        $request->execute();
        $response = $request;
        unset($pdo);
        return $response;
    }
}

?>
