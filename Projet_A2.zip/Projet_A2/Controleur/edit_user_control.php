<?php
session_start();
require_once "DAO.php";


$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$username = $_POST['username'];
$password = $_POST['password'];
$salt = 'projetdanea2';
$pwdsecure = md5($password.$salt);
$civilite = $_POST['reg_gender'];
$email = $_POST['email'];


if($nom != $_SESSION['nom'] || $prenom != $_SESSION['prenom'] || $username != $_SESSION['username'] || $email != $_SESSION['email']){
    if ($nom != $_SESSION['nom']){
        $dao = new DAO();
        $query = "UPDATE users
        SET nom =" . " '" . $nom ."'" .
        " WHERE id_user = " . $_SESSION['id'] . ";";
        $dao->update($query);
    }
    if ($prenom != $_SESSION['prenom']){
        $dao = new DAO();
        $query = "UPDATE users
        SET prenom =" . " '" . $prenom ."'" .
        " WHERE id_user = " . $_SESSION['id'] . ";";
        $dao->update($query);
    }
    if ($username != $_SESSION['username']){
        $dao = new DAO();
        $query = "UPDATE users
        SET username =" . " '" . $username ."'" .
        " WHERE id_user = " . $_SESSION['id'] . ";";
        $dao->update($query);
    }
    if ($email != $_SESSION['email']){
        $dao = new DAO();
        $query = "UPDATE users
        SET email =" . " '" . $email ."'" .
        " WHERE id_user = " . $_SESSION['id'] . ";";
        $dao->update($query);
    }

    ?>
    <script LANGUAGE="JavaScript"> alert("L'utilisateur à bien été modifié'"); </script>
    <meta http-equiv="refresh" content="0; URL=../index.php?redirect=users_table"/>
    <?php
}
else{
    ?>
    <script LANGUAGE="JavaScript"> alert("Les informations de l'utilisateur n'ont pas été modifié"); </script>
    <meta http-equiv="refresh" content="0; URL=../index.php?redirect=users_table"/>
    <?php
}


/*if($_POST['password'] == $_POST['confirm_password'])
{  
    $destinataire = 'cyprien.falavel@ac-lyon.fr';
    // Pour les champs $expediteur / $copie / $destinataire, séparer par une virgule s'il y a plusieurs adresses
    $expediteur = 'cyprien.falavel@ac-lyon.fr';
    $objet = 'Test'; // Objet du message
    $headers  = 'MIME-Version: 1.0' . "\n"; // Version MIME
    $headers .= 'Reply-To: '.$expediteur."\n"; // Mail de reponse
    $headers .= 'From: "Nom_de_expediteur"<'.$expediteur.'>'."\n"; // Expediteur
    $headers .= 'Delivered-to: '.$destinataire."\n"; // Destinataire
    $headers .= 'Cc: '.$copie."\n"; // Copie Cc
    $headers .= 'Bcc: '.$copie_cachee."\n\n"; // Copie cachée Bcc        
    $message = 'Un Bonjour de Developpez.com!';
    mail($destinataire, $objet, $message, $headers)
    ?>
    <script LANGUAGE="JavaScript"> alert("L'utilisateur à bien été modifier"); </script>
    <meta http-equiv="refresh" content="0; URL=../index.php?redirect=users_table" />
    <?php
} 
else
{
    ?>
        <script LANGUAGE="JavaScript"> alert("Les deux mots de passe saisie sont différents"); </script>
        <meta http-equiv="refresh" content="0; URL=../index.php?redirect=users_table"/>
    <?php
}*/

?>