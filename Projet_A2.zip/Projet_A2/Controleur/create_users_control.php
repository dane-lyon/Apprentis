<?php
$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$username = $_POST['username'];
$password = $_POST['password'];
$confirm_password = $_POST['confirm_password'];
$salt = 'projetdanea2';
$pwdsecure = md5($password.$salt);
$civilite = $_POST['reg_gender'];
$email = $_POST['email'];



if($password == $confirm_password)
{ 
    require_once 'DAO.php';
    
    $dao = new DAO();
    $table = 'users(nom,prenom,username,password,civilite,email)';
    $values = '"'. $nom . '","' . $prenom . '","' . $username . '","' . $pwdsecure . '","' . $civilite . '","' . $email . '"';
    $dao->create($table, $values);
    
    
    ?>
    <script LANGUAGE="JavaScript"> alert("L'utilisateur a bien été créé"); </script>
    <meta http-equiv="refresh" content="0; URL=../index.php?redirect=create_account"/>
    <?php
} 
else
{
    ?>
        <script LANGUAGE="JavaScript"> alert("Les deux mots de passe saisis sont différents"); </script>
        <meta http-equiv="refresh" content="0; URL=../index.php?redirect=create_account"/>
    <?php
}
?>