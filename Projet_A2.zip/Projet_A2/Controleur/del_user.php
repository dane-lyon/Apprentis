<?php
require('DAO.php');
session_start();

if(isset($_GET['id'])){
    if($_GET['id'] != $_SESSION['id_user']){

        $dao = new DAO();
        $table = "users";
        $condition = "id_user = " . $_GET['id'];
        $dao->delete($table, $condition);

        echo '<script LANGUAGE="JavaScript"> alert("L\'utilisateur a bien été supprimé"); </script>
        <meta http-equiv="refresh" content="0; URL=../index.php?redirect=users_table"/>';
    }
    else{
        echo '<script LANGUAGE="JavaScript"> alert("Vous ne pouvez pas supprimer votre propre compte"); </script>
        <meta http-equiv="refresh" content="0; URL=../index.php?redirect=users_table"/>';
    }
    
    
    }
else{
    echo '<script LANGUAGE="JavaScript"> alert("L\utilisateur n\'a pas pu être supprimé "); </script>
    <meta http-equiv="refresh" content="0; URL=../index.php?redirect=users_table"/>';
}

?>