<div class="col-xs-6 col-md-offset-3">
    <div class="col-md-12">
        <h3>Migration :</h3>
        <div class="form-group">
        <label class="control-label">Numero du service easyvista</label>
        <input maxlength="200" type="text" class="form-control" name="num_service_mig" placeholder="Entrer le numero de service easyvista de la migration" required/>
        </div>
        <div class="form-group">
        <label class="control-label">Date de la demande</label>
        <input maxlength="200" type="date" class="form-control" name="date_demande_mig" placeholder="Entrer la date de la demande de migration"  required/>
        </div>
        <div class="form-group">
        <label class="control-label">Date de la migration</label>
        <input maxlength="200" type="date" class="form-control" name="date_mig" placeholder="Entrer l'auteur de la migration du site"  required/>
        </div>
        <div class="form-group">
        <label class="control-label">Auteur de la migration</label>
        <input maxlength="200" type="text" class="form-control" name="aut_mig" placeholder="Entrer la date de la migration"  required/>
        </div>
        <div class="form-group">
        <label class="control-label">Version Spip</label>
        <input maxlength="200" type="text" class="form-control" name="version_spip" placeholder="Entrer la version du spip"  required/>
        </div>
        <div class="form-group">
        <label class="control-label">Version Escal</label>
        <input maxlength="200" type="text" class="form-control" name="version_escal" placeholder="Entrer la version d'escal" required/>
        </div>
        <div class="pull-right wizard-nav">
        <button type="button" class="btn btn-primary nextBtn">Next step</button>
        </div>
    </div>
</div>