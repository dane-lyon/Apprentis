<div class="col-xs-6 col-md-offset-3">
<div class="col-md-12">
<h3>Demande de création :</h3>
        <div class="form-group">
        <label class="control-label">Numero de service Easyvista</label>
        <input maxlength="200" type="text" class="form-control" name="num_serv_crea" placeholder="Entrer le numero de service easyvista de la création du site"  required/>
        </div>
        <div class="form-group">
        <label class="control-label">Date de la demande</label>
        <input maxlength="200" type="date" class="form-control" name="date_demande_crea" placeholder="Entrer la date de la demande de création du site"  required/>
        </div>
        <div class="form-group">
        <label class="control-label">Date de résolution </label>
        <input maxlength="200" type="date" class="form-control" name="date_reso_crea" placeholder="Entrer la date de la résolution de la demande"  required/>
        </div>
        <div class="form-group">
        <label class="control-label">Nom du rapport</label>
        <input maxlength="200" type="text" class="form-control" name="nom_rapport_crea" placeholder="Entrer le nom du rapport"  required/>
        </div>
        <div class="form-group">
        <label class="control-label">Upload rapport</label>
        <input maxlength="200" type="text" class="form-control" name="upload_rapport_crea" placeholder="Entrer l'upload du rapport"  required/>
        </div>
        <div class="pull-right wizard-nav">
        <button type="button" class="btn btn-primary nextBtn">Next step</button>
        </div>
    </div>
</div>