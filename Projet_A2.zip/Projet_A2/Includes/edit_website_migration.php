<div class="col-xs-6 col-md-offset-3">
    <div class="col-md-12">
        <h3>Migration :</h3>
        <div class="form-group">
        <label class="control-label">Numero du service easyvista</label>
        <input maxlength="200" type="text" class="form-control" name="num_service_mig" value=<?= $_SESSION['num_service_ev_m'] = $data["num_service_ev_m"] ?> required/>
        </div>
        <div class="form-group">
        <label class="control-label">Date de la demande</label>
        <input maxlength="200" type="date" class="form-control" name="date_demande_mig" value=<?= $_SESSION['date_demande_m'] = $data["date_demande_m"] ?>  required/>
        </div>
        <div class="form-group">
        <label class="control-label">Date de la migration</label>
        <input maxlength="200" type="date" class="form-control" name="date_mig" value=<?= $_SESSION['date_migration_m'] = $data["date_migration_m"] ?>  required/>
        </div>
        <div class="form-group">
        <label class="control-label">Auteur de la migration</label>
        <input maxlength="200" type="text" class="form-control" name="aut_mig" value=<?= $_SESSION['auteur_migration_m'] = $data["auteur_migration_m"] ?>  required/>
        </div>
        <div class="form-group">
        <label class="control-label">Version Spip</label>
        <input maxlength="200" type="text" class="form-control" name="version_spip" value=<?= $_SESSION['version_spip_m'] = $data["version_spip_m"] ?>  required/>
        </div>
        <div class="form-group">
        <label class="control-label">Version Escal</label>
        <input maxlength="200" type="text" class="form-control" name="version_escal" value=<?= $_SESSION['version_escal_m'] = $data["version_escal_m"] ?> required/>
        </div>
        <div class="pull-right wizard-nav">
        <button type="button" class="btn btn-primary nextBtn">Next step</button>
        </div>
    </div>
</div>