<div class="col-xs-6 col-md-offset-3">
    <div class="col-md-12">
        <h3> Base de données :</h3>
        <div class="form-group">
        <label class="control-label">Nom</label>
        <input  maxlength="100" type="text" class="form-control" name="nom_bdd" placeholder="Entrer le nom de la base de données" required />
        </div>
        <div class="form-group">
        <label class="control-label">Utilisateur de la base de données</label>
        <input maxlength="100" type="text" class="form-control" name="user_bdd" placeholder="Entrer l'utilisateur de la base de données" required/>
        </div>
        <div class="form-group">
        <label class="control-label">Mot de passe de la base de données</label>
        <input maxlength="100" type="text" class="form-control" name="pwd_bdd" placeholder="Entrer le mot de passe de la base de données" required/>
        </div>
        <div class="pull-right wizard-nav">
        <button type="button" class="btn btn-primary nextBtn">Next step</button>
        </div>
    </div>
</div>