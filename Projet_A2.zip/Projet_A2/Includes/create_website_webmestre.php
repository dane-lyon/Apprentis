<div class="col-xs-6 col-md-offset-3">
    <div class="col-md-12">
        <h3> Webmestre :</h3>
        <div class="form-group">
        <label class="control-label">Nom</label>
        <input  maxlength="100" type="text" class="form-control" name="nom_web" placeholder="Entrer le nom du webmestre"  required/>
        </div>
        <div class="form-group">
        <label class="control-label">Prénom</label>
        <input maxlength="100" type="text" class="form-control" name="prenom_web" placeholder="Entrer le prénom du webmestre" required/>
        </div>
        <div class="form-group">
        <label class="control-label">Fonction</label>
        <select name="fonction_web" class="form-control">
            <option value="Professeur">Professeur</option>
            <option value="...">...</option>
            <option value="...">...</option>
        </select>
        </div>
        <div class="form-group">
        <label class="control-label">Adresse mail</label>
        <input maxlength="100" type="text" class="form-control" name="mail_web" placeholder="Entrer l'adresse mail du webmestre" required/>
        </div>
        <div class="form-group">
        <label class="control-label">Civilité</label>
        <select name="civilite_web" class="form-control">
            <option value="Madame">Madame</option>
            <option value="Monsieur">Monsieur</option>
        </select>
        </div>
        <div class="form-group">
        <label class="control-label">Identifiant</label>
        <input maxlength="100" type="text" class="form-control" name="identifiant_web" placeholder="Entrer l'identifiant du webmestre" required/>
        </div>
        <div class="form-group">
        <label class="control-label">Mot de passe</label>
        <input maxlength="100" type="text" class="form-control" name="pwd_web" placeholder="Entrer le mot de passe du webmestre" required/>
        </div>
        <br>
        <h3> Courrier au directeur de publication :</h3>
        <div class="form-group">
        <label class="control-label">Nom du courrier</label>
        <input maxlength="100" type="text" class="form-control" name="nom_courrier_web" placeholder="Entrer le nom du courrier à destination du webmestre" required/>
        </div>
        <div class="form-group">
        <label class="control-label">Upload du courrier</label>
        <input maxlength="100" type="text" class="form-control" name="upd_courrier_web" placeholder="Entrer l'upload du courrier à destination du webmestre" required/>
        </div>
        <!--<input type="submit" class="btn btn-primary pull-right">-->

        <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#enregistrer">Enregistrer</button>

       
        <div class="modal fade" id="enregistrer" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <h3 class="modal-title" id="ModalLabel"><center>Fin de Création</center></h3>
                </div>
                <center>
                    <div class="modal-body">
                        Voulez-vous vraiment enregistrer la création ?<br>
                    </div>
                </center>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Continuer</button>
                    <input type="submit" class="btn btn-primary pull-right">
                </div>
                </div>
            </div>
        </div>
        </div>
</div>
    