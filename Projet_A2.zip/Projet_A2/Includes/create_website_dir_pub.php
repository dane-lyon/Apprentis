<div class="col-xs-6 col-md-offset-3">
    <div class="col-md-12">
        <h3> Directeur de publication :</h3>
        <div class="form-group">
        <label class="control-label">Nom</label>
        <input  maxlength="100" type="text" class="form-control" name="nom_dir_pub" placeholder="Entrer le nom du directeur de publication"  required/>
        </div>
        <div class="form-group">
        <label class="control-label">Prénom</label>
        <input maxlength="100" type="text" class="form-control" name="prenom_dir_pub" placeholder="Entrer le prénom du directeur de publication" required/>
        </div>
        <div class="form-group">
        <label class="control-label">Fonction</label>
        <select name="fonction_dir_pub" class="form-control">
            <option value="Professeur">Professeur</option>
            <option value="...">...</option>
            <option value="...">...</option>
        </select>
        </div>
        <div class="form-group">
        <label class="control-label">Adresse mail</label>
        <input maxlength="100" type="text" class="form-control" name="mail_dir_pub" placeholder="Entrer l'adresse mail du directeur de publication" required/>
        </div>
        <div class="form-group">
        <label class="control-label">Civilité</label>
        <select name="civilite_dir_pub" class="form-control">
            <option value="Madame">Madame</option>
            <option value="Monsieur">Monsieur</option>
        </select>
        </div>
        <div class="form-group">
        <label class="control-label">Identifiant</label>
        <input maxlength="100" type="text" class="form-control" name="identifiant_dir_pub" placeholder="Entrer l'identifiant du directeur de publication" required/>
        </div>
        <div class="form-group">
        <label class="control-label">Mot de passe</label>
        <input maxlength="100" type="text" class="form-control" name="pwd_dir_pub" placeholder="Entrer le mot de passe du directeur de publication" required/>
        </div>
        <br>
        <h3> Courrier au directeur de publication :</h3>
        <div class="form-group">
        <label class="control-label">Nom du courrier</label>
        <input maxlength="100" type="text" class="form-control" name="nom_courrier_dir_pub" placeholder="Entrer le nom du courrier à destination du directeur de publication" required/>
        </div>
        <div class="form-group">
        <label class="control-label">Upload du courrier</label>
        <input maxlength="100" type="text" class="form-control" name="upd_courrier_dir_pub" placeholder="Entrer l'upload du courrier à destination du directeur de publication" required/>
        </div>
        <div class="pull-right wizard-nav">
        <button type="button" class="btn btn-primary nextBtn">Next step</button>
        </div>
    </div>
</div>
    