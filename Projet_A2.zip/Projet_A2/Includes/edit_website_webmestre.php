<div class="col-xs-6 col-md-offset-3">
    <div class="col-md-12">
        <h3> Webmestre :</h3>
        <div class="form-group">
        <label class="control-label">Nom</label>
        <input  maxlength="100" type="text" class="form-control" name="nom_web" value=<?= $_SESSION['nom_web'] = $data["nom_web"] ?>  required/>
        </div>
        <div class="form-group">
        <label class="control-label">Prénom</label>
        <input maxlength="100" type="text" class="form-control" name="prenom_web" value=<?= $_SESSION['prenom_web'] = $data["prenom_web"] ?> required/>
        </div>
        <div class="form-group">
        <label class="control-label">Fonction</label>
        <select name="fonction_web" class="form-control">
            <option value=<?= $data["fonction_web"] ?>><?= $_SESSION['fonction_web'] = $data["fonction_web"] ?></option>
            <option value="Professeur">Professeur</option>
            <option value="...">...</option>
            <option value="...">...</option>
        </select>
        </div>
        <div class="form-group">
        <label class="control-label">Adresse mail</label>
        <input maxlength="100" type="text" class="form-control" name="mail_web" value=<?= $_SESSION['mail_web'] = $data["mail_web"] ?> required/>
        </div>
        <div class="form-group">
        <label class="control-label">Civilité</label>
        <select name="civilite_web" class="form-control">
            <option value=<?= $data["civilite_web"] ?>><?= $_SESSION['civilite_web'] = $data["civilite_web"] ?></option>
            <option value="Madame">Madame</option>
            <option value="Monsieur">Monsieur</option>
        </select>
        </div>
        <div class="form-group">
        <label class="control-label">Identifiant</label>
        <input maxlength="100" type="text" class="form-control" name="identifiant_web" value=<?= $_SESSION['identifiant_web'] = $data["identifiant_web"] ?> required/>
        </div>
        <div class="form-group">
        <label class="control-label">Mot de passe</label>
        <input maxlength="100" type="text" class="form-control" name="pwd_web" value=<?= $_SESSION['mdp_web'] = $data["mdp_web"] ?> required/>
        </div>
        <br>
        <h3> Courrier au directeur de publication :</h3>
        <div class="form-group">
        <label class="control-label">Nom du courrier</label>
        <input maxlength="100" type="text" class="form-control" name="nom_courrier_web" value=<?= $_SESSION['nom_courrier_web'] = $data["nom_courrier_web"] ?> required/>
        </div>
        <div class="form-group">
        <label class="control-label">Upload du courrier</label>
        <input maxlength="100" type="text" class="form-control" name="upd_courrier_web" value=<?= $_SESSION['upload_courrier_web'] = $data["upload_courrier_web"] ?> required/>
        </div>
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modifier">Modifier</button>

       
        <div class="modal fade" id="modifier" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    <h3 class="modal-title" id="ModalLabel"><center>Fin de modification</center></h3>
                </div>
                <center>
                    <div class="modal-body">
                        Voulez-vous vraiment enregistrer les modifications ?<br>
                    </div>
                </center>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Continuer</button>
                    <input type="submit" class="btn btn-primary pull-right">
                </div>
                </div>
            </div>
        </div>
        </div>
        </div>
</div>
    