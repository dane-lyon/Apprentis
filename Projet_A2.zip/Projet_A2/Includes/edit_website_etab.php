<div class="col-xs-6 col-md-offset-3">
    <div class="col-md-12">
        <h3> Etablissement :</h3>
        <div class="form-group">
        <label class="control-label">RNE</label>
        <input  maxlength="100" type="text" class="form-control" name="rne_etab" value=<?= $_SESSION['rne'] = $data["rne"] ?> required/>
        </div>
        <div class="form-group">
        <label class="control-label">Type</label>
        <select name="type_etab" class="form-control">
            <option value=<?= $data["type"] ?>><?= $_SESSION['type'] = $data["type"] ?></option>
            <option value="Lycée">Lycée</option>
            <option value="Ecole">Ecole</option>
            <option value="Collège">Collège</option>
            <option value="Collège">Autre</option>
        </select>
        </div>
        <div class="form-group">
        <label class="control-label">Nom</label>
        <input maxlength="100" type="text" class="form-control" name="nom_etab" value=<?= $_SESSION['nom_etab'] = $data["nom_etab"] ?> required/>
        </div>
        <div class="form-group">
        <label class="control-label">Commune</label>
        <input  maxlength="100" type="text" class="form-control" name="commune" value=<?= $_SESSION['commune'] = $data["commune"] ?> required/>    
        </div>
        <div class="form-group">
        <label class="control-label">Collectivité</label>
        <select name="col_etab" class="form-control">
            <option value=<?= $data["collectivite"] ?>><?= $_SESSION['collectivite'] = $data["collectivite"] ?></option>
            <option value="Métropole">AURA</option>
            <option value="Ain">Ain</option>
            <option value="Ain">Loire</option>
            <option value="Rhône">Métropole de Lyon</option>
            <option value="Ain">Rhône</option>
        </select> 
        </div>
        <div class="pull-right wizard-nav">
        <button type="button" class="btn btn-primary nextBtn">Next step</button>
        </div>
    </div>
</div>
    