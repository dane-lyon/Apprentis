<br>
<br>
<br>
<div class="footer">
    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
        <div class="bassite">
            <!-- Logo mention CC + lien mention CC -->
            <a rel="license" href="https://creativecommons.org/licenses/by-nc-sa/3.0/fr/" target="_BLANK">
                <img src="Model/Images/CC.png"></a>
        </div>
        <div class="copyright">
            <!-- Acces Bootstrap -->
            <font color="black"> CSS : </font> <a target="_blank" href="http://getbootstrap.com/"><b>Bootstrap 3.3.7</b></a>
        </div>
    </div>
    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
        <!-- Credits -->
        <div class="design">
            Par <i>Cyprien Falavel</i>
        </div>
    </div>
</div>
