<div class="col-xs-6 col-md-offset-3">
    <div class="col-md-12">
    <h3> Site :</h3>
    <div class="form-group">
      <label class="control-label">URL Publique</label>
      <p><input maxlength="200" type="text" class="form-control" name="url_publique" value=<?= $_SESSION['url_publique'] = $data["url_publique"] ?> required/>
    </div>
    <div class="form-group">
      <label class="control-label">URL Privée</label>
      <input maxlength="200" type="text" class="form-control" name="url_privee" value=<?= $_SESSION['url_privee'] = $data["url_privee"] ?>  required/>
    </div>
    <div class="form-group">
      <label class="control-label">Protocole</label>
      <input maxlength="200" type="text" class="form-control" readOnly="readOnly"  name="url_privee" value="SFTP" required/>
    </div>
    <div class="form-group">
      <label class="control-label">Hôte</label>
      <input maxlength="200" type="text" class="form-control" name="hote_site" value=<?= $_SESSION['hote'] = $data["hote"] ?>  required/>
    </div>
    <div class="form-group">
      <label class="control-label">Port</label>
      <input maxlength="200" type="text" class="form-control" name="port_site" value=<?= $_SESSION['port'] = $data["port"] ?>  required/>
    </div>
    <div class="form-group">
      <label class="control-label">Id Hôte</label>
      <input maxlength="200" type="text" class="form-control" name="id_hote_site" value=<?= $_SESSION['id_hote'] = $data["id_hote"] ?>  required/>
    </div>
    <div class="form-group">
      <label class="control-label">Mot de passe de l'hôte</label>
      <input maxlength="200" type="text" class="form-control" name="mdp_hote_site" value=<?= $_SESSION['mdp_hote'] = $data["mdp_hote"] ?>  required/>
    </div>
    <div class="pull-right wizard-nav">
    <button type="button" class="btn btn-primary nextBtn">Next step</button>
    </div>
  </div>
</div>