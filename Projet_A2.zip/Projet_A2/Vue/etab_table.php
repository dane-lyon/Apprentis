<?php
include "Includes/navbar.php";
?>

<html>

<div class="panel panel-primary">
    <div class="panel-heading">
        <h3 class="panel-title">Vous êtes en mode Editeur</h3>
    </div>
        <a href="index.php?redirect=create_website" class="btn btn-primary align-right">Créer un site</a>
    <div class="panel-body">
        <table id="tab_etab" class="table table-striped table-bordered dt-responsive">
            <thead>
                <tr>
                    <th>Nom établissment</th>
                    <th>URL publique</th>
                    <th>Serveur hôte</th>
                    <th>ID serveur</th>
                    <th>MDP serveur</th>
                    <th>Nom BDD</th>
                    <th>Utilisateur BDD</th>
                    <th>MDP BDD</th>
                    <th>Modifier</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    require('Controleur/DAO.php');
                    
                    $dao = new DAO();
                    $request = "SELECT e.id_etab, nom_etab, s.id_site, url_publique, hote, id_hote, mdp_hote, id_bdd, nom_bdd, utilisateur_bdd, mdp_bdd
                     FROM etablissement e, site s, bdd_site b
                     WHERE e.id_etab = s.id_etab
                     AND s.id_site = b.id_site;";
                    $response = $dao->selectFromSQL($request);

                    while($info = $response->fetch()){
                        $id_etab = $info["id_etab"];
                        $nom_etab = $info['nom_etab'];
                        $url_publique = $info['url_publique'];
                        $serv_hote = $info['hote'];
                        $id_serveur = $info['id_hote'];
                        $mdp_serveur = $info['mdp_hote'];
                        $nom_bdd = $info['nom_bdd'];
                        $user_bdd = $info['utilisateur_bdd'];
                        $mdp_bdd = $info['mdp_bdd'];
                    ?>
                    <tr>
                        <td><?= $nom_etab; ?></td>
                        <td><?= $url_publique; ?></td>
                        <td><?= $serv_hote; ?></td>
                        <td><?= $id_serveur; ?></td>
                        <td><?= $mdp_serveur; ?></td>
                        <td><?= $nom_bdd; ?></td>
                        <td><?= $user_bdd; ?></td>
                        <td><?= $mdp_bdd; ?></td>
                        <td> 
                            <a href=<?= "index.php?redirect=edit_etab&id_etab=".$id_etab; ?> class="btn btn-primary"><span class="glyphicon glyphicon glyphicon-pencil" aria-hidden="true"></span></a>
                            <button type="button" class="btn btn-danger" class="btn btn-danger pull-right" data-toggle="modal" data-target=<?= "#annuler".$id_etab; ?>><span class="glyphicon glyphicon glyphicon-remove" aria-hidden="true"></span></button>

                            <!-- Modal -->
                            <div class="modal fade" id=<?= "annuler".$id_etab; ?> tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                        <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                            </button>
                                            <h3 class="modal-title" id="ModalLabel"><center>Suppression</center></h3>
                                        </div>
                                        <center>
                                            <div class="modal-body">
                                                Voulez-vous vraiment supprimer ce site ?<br>
                                            </div>
                                        </center>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Non</button>
                                            <a href="Controleur/del_site.php?id=<?= $id_etab; ?>" class="btn btn-danger">Oui</a>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                        </td>
                    </tr>
                                    
                    <?php  }
                    ?>
            </tbody>
        </table>
    </div>
</div>
</html>


<?php
include "Includes/footer.php";
?>