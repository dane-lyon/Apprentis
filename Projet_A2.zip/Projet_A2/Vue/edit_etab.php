<?php
$id_etab = $_GET['id_etab'];
$_SESSION['id_etab'] = $id_etab;
require('Controleur/DAO.php');
$dao = new DAO();
$request = "SELECT b.id_site, dc.id_site, m.id_site, s.id_site, 
cdp.id_dir_publication, dp.id_dir_publication, 
cw.id_webmestre, w.id_webmestre, 
e.id_etab, w.id_etab, dp.id_etab,
utilisateur_bdd, mdp_bdd, nom_courrier_dir_pub, upload_courrier_dir_pub, 
nom_courrier_web, upload_courrier_web, nom_bdd,
num_service_ev_dc, date_demande_dc, date_resolu_dc, nom_rapport_dc, 
upload_rapport_dc, nom_dp, prenom_dp, fonction_dp, mail_dp, 
civilite_dp, identifiant_dp, mdp_dp, rne, type, nom_etab, commune, 
collectivite, num_service_ev_m, date_demande_m, date_migration_m, 
auteur_migration_m, version_spip_m, version_escal_m, url_publique, 
url_privee, protocole, hote, port, id_hote, mdp_hote, nom_web, prenom_web, 
fonction_web, mail_web, civilite_web, identifiant_web, mdp_web 
 FROM webmestre w, 
 courrier_dir_publication cdp, 
 courrier_webmestre cw, demande_creation dc, 
 dir_publication dp, 
 migration m, 
 etablissement e, 
 site s, 
 bdd_site b
 WHERE e.id_etab =" . $id_etab . "
 AND e.id_etab = s.id_etab
 AND e.id_etab = w.id_etab
 AND e.id_etab = dp.id_etab
 AND dp.id_dir_publication = cdp.id_dir_publication
 AND w.id_webmestre = cw.id_webmestre
 AND s.id_site = b.id_site
 AND s.id_site = dc.id_site
 AND s.id_site = m.id_site
 ;";
$response = $dao->selectFromSQL($request);
$data = $response->fetch();
$_SESSION['id_site'] = $data["id_site"];
$_SESSION['id_dir_publication'] = $data['id_dir_publication'];
$_SESSION['webmestre'] = $data['id_webmestre'];


//Information pour PDF
$_SESSION['nom_dp'] = $data["id_site"];
$_SESSION['prenom_dp'] = $data["id_site"];
$_SESSION['civilite_dp'] = $data["id_site"];
$_SESSION['nom_etab'] = $data["id_site"];
$_SESSION['url_publique'] = $data["id_site"];
$_SESSION['url_privee '] = $data["id_site"];
$_SESSION['identifiant_dp'] = $data["id_site"];
$_SESSION['mdp_dp'] = $data["id_site"];

?>

<div class="container">
    <div class="stepwizard col-md-offset-3">
        <div class="stepwizard-row setup-panel">
        <div class="stepwizard-step">
            <a href="#step-1" type="button" data-toggle="tab" class="btn btn-primary btn-circle">1</a>
            <p>Etablissement</p>
        </div>
        <div class="stepwizard-step">
            <a href="#step-2" type="button" data-toggle="tab" class="btn btn-default btn-circle">2</a>
            <p>Site</p>
        </div>
        <div class="stepwizard-step">
            <a href="#step-3" type="button" data-toggle="tab" class="btn btn-default btn-circle">3</a>
            <p>Demande <br>de<br> création</p>
        </div>
        <div class="stepwizard-step">
            <a href="#step-4" type="button" data-toggle="tab" class="btn btn-default btn-circle">4</a>
            <p>Migration</p>
        </div>
        <div class="stepwizard-step">
            <a href="#step-5" type="button" data-toggle="tab" class="btn btn-default btn-circle">5</a>
            <p>BDD</p>
        </div>
        <div class="stepwizard-step">
            <a href="#step-6" type="button" data-toggle="tab" class="btn btn-default btn-circle">6</a>
            <p>Directeur <br>de<br> Publication</p>
        </div>
        <div class="stepwizard-step">
            <a href="#step-7" type="button" data-toggle="tab" class="btn btn-default btn-circle">7</a>
            <p>Webmestre</p>
        </div>
        </div>
    </div>
    <div class="panel panel-primary">
<form role="form" action="Controleur/edit_etab_control.php" method="post">
        <div class="row setup-content" id="step-1">
            <?php
                include("Includes/edit_website_etab.php") ;
            ?>
        </div>


        <div class="row setup-content" id="step-2">
            <?php
                include("Includes/edit_website_site.php") ;
            ?>
        </div>

        <div class="row setup-content" id="step-3">
            <?php
                include("Includes/edit_website_crea.php") ;
            ?>
        </div>

        <div class="row setup-content" id="step-4">
            <?php
                include("Includes/edit_website_migration.php") ;
            ?>
        </div>


        <div class="row setup-content" id="step-5">
            <?php
                include("Includes/edit_website_bdd.php") ;
            ?>
        </div>


        <div class="row setup-content" id="step-6">
            <?php
                include("Includes/edit_website_dir_pub.php") ;
            ?>
        </div>


        <div class="row setup-content" id="step-7">
            <?php
                include("Includes/edit_website_webmestre.php") ;
            ?>
        </div>
        
    </div>
</form>
<button type="button" class="btn btn-danger pull-right" data-toggle="modal" data-target="#annuler">Annuler</button>

<!-- Modal -->
<div class="modal fade" id="annuler" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
                <h3 class="modal-title" id="ModalLabel"><center>Annulation</center></h3>
            </div>
            <center>
                <div class="modal-body">
                    Voulez-vous vraiment revenir à la page précédente ?<br>
                    Aucune modification ne sera enregistré
                </div>
            </center>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Continuer</button>
                <a href="index.php?redirect=etab_table" class="btn btn-danger">Annuler</a>
            </div>
            </div>
        </div>
    </div>
  
</div>
<a href="PDF/Creation_dir_pub_2018.php" target="_blank" class="btn btn-primary">PDF 1</a>  
<a href="PDF/Creation_id_2018.php" target="_blank" class="btn btn-primary">PDF 2</a>
<a href="PDF/Creation_id_webm_2018.php" target="_blank" class="btn btn-primary">PDF 3</a>
<a href="PDF/Creation_webmestre_2018.php" target="_blank" class="btn btn-primary">PDF 4 </a>
        

<?php
include "Includes/footer.php";
?>