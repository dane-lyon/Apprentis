<html>
    <body>       
        <!-- FORGOT PASSWORD FORM -->
        <div class="text-center" style="padding:50px 0">
            <div class="logo">Mot de passe oublié</div>
            <!-- Main Form -->
            <div class="login-form-1">
                <form id="forgot-password-form" class="text-left" method="post" action="Controleur/forgot_pwd_control.php">
                    <div class="etc-login-form">
                        <p>Un nouveau mot de passe vous seras automatiquement envoyé par mail.</p>
                    </div>
                    <div class="login-form-main-message"></div>
                    <div class="main-login-form">
                        <div class="login-group">
                            <div class="form-group">
                                <label for="fp_email" class="sr-only">Adresse Mail</label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="Adresse Mail" required>
                            </div>
                        </div>
                        <button type="submit" class="login-button"><i class="fa fa-chevron-right"></i></button>
                    </div>
                    <div class="etc-login-form">
                        <p>Vous avez déjà un compte ? <a href="index.php">Connectez vous ici</a></p>
                    </div>
                </form>
            </div>
            <!-- end:Main Form -->
        </div>
    </body>
</html>


<?php
include "Includes/footer.php";
?>