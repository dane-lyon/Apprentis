<?php
include "Includes/navbar.php";
?>

<html>
<div class="panel panel-danger">
    <div class="panel-heading">
        <h3 class="panel-title">Vous êtes en mode Administrateur</h3>
    </div>
        <a href="index.php?redirect=create_account" class="btn btn-primary align-right">Créer compte</a>
    <div class="panel-body">
        <table id="tab_users" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>Civilité</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Identifiant</th>
                    <th>Email</th>
                    <th>Modifier</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    require('Controleur/DAO.php');
                    
                    $dao = new DAO();
                    $request = "SELECT id_user,nom, prenom, username, civilite, email FROM users;";
                    $response = $dao->selectFromSQL($request);

                    while($info = $response->fetch()){
                        $id_user = $info['id_user'];
                        $name = $info['nom'];
                        $firstname = $info['prenom'];
                        $username = $info['username'];
                        $civilite = $info['civilite'];
                        $email = $info['email'];
                    ?>
                    <tr>
                        <td><?= $civilite; ?></td>
                        <td><?= $name ?></td>
                        <td><?= $firstname; ?></td>
                        <td><?= $username; ?></td>
                        <td><?= $email; ?></td>
                        <td> 
                            <a href=<?= "index.php?redirect=edit_user&id_user=".$id_user; ?> class="btn btn-primary"><span class="glyphicon glyphicon glyphicon-pencil" aria-hidden="true"></span></a>
                            <button type="button" class="btn btn-danger" class="btn btn-danger pull-right" data-toggle="modal" data-target=<?= "#annuler".$id_user; ?>><span class="glyphicon glyphicon glyphicon-remove" aria-hidden="true"></span></button>

                            <!-- Modal -->
                            <div class="modal fade" id=<?= "annuler".$id_user; ?> tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                        <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                            </button>
                                            <h3 class="modal-title" id="ModalLabel"><center>Suppression</center></h3>
                                        </div>
                                        <center>
                                            <div class="modal-body">
                                                Voulez-vous vraiment supprimer cet utilisateur ?<br>
                                            </div>
                                        </center>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Non</button>
                                            <a href="Controleur/del_user.php?id=<?= $id_user; ?>" class="btn btn-danger">Oui</a>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                        
                        
                        
                        
                        </td>
                    </tr>
                                    
                    <?php  }
                    ?>
            </tbody>
        </table>
    </div>
</div>

</html>

<?php
include "Includes/footer.php";
?>