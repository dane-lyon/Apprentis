<?php
require('Controleur/DAO.php');

$dao = new DAO();
$request = "SELECT id_user,nom, prenom, username, email FROM users WHERE id_user =" . $_GET["id_user"] . ";";
$response = $dao->selectFromSQL($request);
$data = $response->fetch();

$_SESSION['id'] = $data['id_user'];
$_SESSION['nom'] = $data['nom'];
$_SESSION['prenom'] = $data["prenom"];
$_SESSION['username'] = $data['username'];
$_SESSION['email'] = $data['email'];

?>

<div class="text-center" style="padding:50px 0">
	<div class="logo">Modification du compte :</br> <?= $data['nom']. " " . $data['prenom']; ?></div>
	<!-- Main Form -->
	<div class="login-form-1">
		<form id="register-form" class="text-left" method="post" action="Controleur/edit_user_control.php">
			<div class="login-form-main-message"></div>
			<div class="main-login-form">
				<div class="login-group">
					<div class="form-group">
						<input type="text" class="form-control" id="nom" name="nom" placeholder="Nom" value=<?= $data['nom']; ?> required>
					</div>
					<div class="form-group">
						<input type="test" class="form-control" id="prenom" name="prenom" placeholder="Prénom" value=<?= $data['prenom']; ?> required>
					</div>
					<div class="form-group">
						<input type="test" class="form-control" id="username" name="username" placeholder="Identifiant" value=<?= $data['username']; ?> required>
					</div>
					<div class="form-group">
						<input type="email" class="form-control" id="email" name="email" placeholder="Adresse mail" value=<?= $data['email']; ?> required>
					</div>
					<div class="form-group">
						<input type="password" class="form-control" id="password" name="password" placeholder="Mot de passe" value=******* required>
					</div>
					<div class="form-group">
						<input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirmer mot de passe" value=******* required>
					</div>
				</div>
				<button type="submit" class="login-button"><i class="fa fa-chevron-right"></i></button>
				<div class="etc-login-form">
                    <p>Revenir à la page précédente <a href="index.php?redirect=users_table">Cliquez ici</a></p>
                </div>
			</div>
		</form>
	</div>
	<!-- end:Main Form -->
</div>

<?php
include "Includes/footer.php";
?>