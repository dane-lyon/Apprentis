<div class="container">
    <div class="stepwizard col-md-offset-3">
        <div class="stepwizard-row setup-panel">
        <div class="stepwizard-step">
            <a href="#step-1" type="button" data-toggle="tab" class="btn btn-primary btn-circle">1</a>
            <p>Etablissement</p>
        </div>
        <div class="stepwizard-step">
            <a href="#step-2" type="button" data-toggle="tab" class="btn btn-default btn-circle">2</a>
            <p>Site</p>
        </div>
        <div class="stepwizard-step">
            <a href="#step-3" type="button" data-toggle="tab" class="btn btn-default btn-circle">3</a>
            <p>Demande <br>de<br> création</p>
        </div>
        <div class="stepwizard-step">
            <a href="#step-4" type="button" data-toggle="tab" class="btn btn-default btn-circle">4</a>
            <p>Migration</p>
        </div>
        <div class="stepwizard-step">
            <a href="#step-5" type="button" data-toggle="tab" class="btn btn-default btn-circle">5</a>
            <p>BDD</p>
        </div>
        <div class="stepwizard-step">
            <a href="#step-6" type="button" data-toggle="tab" class="btn btn-default btn-circle">6</a>
            <p>Directeur <br>de<br> Publication</p>
        </div>
        <div class="stepwizard-step">
            <a href="#step-7" type="button" data-toggle="tab" class="btn btn-default btn-circle">7</a>
            <p>Webmestre</p>
        </div>
        </div>
    </div>
    <div class="panel panel-primary">
<form role="form" action="Controleur/create_website_control.php" method="post">
        <div class="row setup-content" id="step-1">
            <?php
                include("Includes/create_website_etab.php") ;
            ?>
        </div>


        <div class="row setup-content" id="step-2">
            <?php
                include("Includes/create_website_site.php") ;
            ?>
        </div>

        <div class="row setup-content" id="step-3">
            <?php
                include("Includes/create_website_crea.php") ;
            ?>
        </div>

        <div class="row setup-content" id="step-4">
            <?php
                include("Includes/create_website_migration.php") ;
            ?>
        </div>


        <div class="row setup-content" id="step-5">
            <?php
                include("Includes/create_website_bdd.php") ;
            ?>
        </div>


        <div class="row setup-content" id="step-6">
            <?php
                include("Includes/create_website_dir_pub.php") ;
            ?>
        </div>


        <div class="row setup-content" id="step-7">
            <?php
                include("Includes/create_website_webmestre.php") ;
            ?>
        </div>
        
    </div>
</form>
<button type="button" class="btn btn-danger pull-right" data-toggle="modal" data-target="#annuler">Annuler</button>

<!-- Modal -->
<div class="modal fade" id="annuler" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
                <h3 class="modal-title" id="ModalLabel"><center>Annulation</center></h3>
            </div>
            <center>
                <div class="modal-body">
                    Voulez-vous vraiment annuler la création ?<br>
                    Aucune modification ne sera enregistré
                </div>
            </center>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Continuer</button>
                <a href="index.php?redirect=etab_table" class="btn btn-danger">Annuler</a>
            </div>
            </div>
        </div>
    </div>
  
</div>

<?php
include "Includes/footer.php";
?>