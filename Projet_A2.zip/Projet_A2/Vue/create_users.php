<div class="text-center" style="padding:50px 0">
	<div class="logo">Création d'un nouveau compte</br> utilisateur</div>
	<!-- Main Form -->
	<div class="login-form-1">
		<form id="register-form" class="text-left" method="post" action="Controleur/create_users_control.php">
			<div class="login-form-main-message"></div>
			<div class="main-login-form">
				<div class="login-group">
					<div class="form-group">
						<input type="text" class="form-control" id="nom" name="nom" placeholder="Nom" required>
					</div>
					<div class="form-group">
						<input type="test" class="form-control" id="prenom" name="prenom" placeholder="Prénom" required>
					</div>
					<div class="form-group">
						<input type="test" class="form-control" id="username" name="username" placeholder="Identifiant" required>
					</div>
					<div class="form-group">
						<input type="email" class="form-control" id="email" name="email" placeholder="Adresse mail" required>
					</div>
					<div class="form-group">
						<input type="password" class="form-control" id="password" name="password" placeholder="Mot de passe" required>
					</div>
					<div class="form-group">
						<input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirmer mot de passe" required>
					</div>
					<div class="form-group login-group-checkbox">
						<input type="radio" name="reg_gender" value="Monsieur" id="male">
						<label for="male">Monsieur</label>
						<input type="radio" name="reg_gender" value="Madame" id="female">
						<label for="female">Madame</label>
					</div>
				</div>
				<button type="submit" class="login-button"><i class="fa fa-chevron-right"></i></button>
				<div class="etc-login-form">
                    <p>Revenir à la page précédente <a href="index.php?redirect=users_table">Cliquez ici</a></p>
                </div>
			</div>
		</form>
	</div>
	<!-- end:Main Form -->
</div>

<?php
include "Includes/footer.php";
?>