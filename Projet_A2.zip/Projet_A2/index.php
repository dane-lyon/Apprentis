<!-- Récupère le head et le style pour toutes les pages-->
<?php
require_once('Controleur/header_page.php');
?>

<php>
<body>
    <?php
        

        // Met la variable SESSION['auth'] à false si non créer
        if(isset($_SESSION['auth']) == false)
        {
            $_SESSION['auth'] = false;
        }
        if($_SESSION['auth'] == true)
        {
            if (isset($_GET["redirect"]) && !empty($_GET["redirect"]))
            {
                // Affiche la page de création d'utilisateur
                if($_GET["redirect"] == "create_account")
                {
                    require_once 'Vue/create_users.php';
                }
                // Affiche vers la page de contenant le tableau des informations des établissement
                else if($_GET["redirect"] == "etab_table")
                {
                    require_once 'Vue/etab_table.php';
                }
                // Affiche vers la page de contenant le tableau des utilisateurs de l'application
                else if($_GET["redirect"] == "users_table")
                {
                    require_once 'Vue/users_table.php';
                }
                else if($_GET["redirect"] == "edit_user")
                {
                    require_once 'Vue/edit_user.php';
                }
                else if($_GET["redirect"] == "edit_etab")
                {
                    require_once 'Vue/edit_etab.php';
                }
                else if($_GET["redirect"] == "create_website")
                {
                    require_once 'Vue/create_website.php';
                }
            }
            else 
            {
                // Affiche vers la page de contenant le tableau des utilisateurs de l'application
                require_once 'Vue/etab_table.php';
            }
            
        }
        else{
            if (isset($_GET["redirect"]) && !empty($_GET["redirect"]))
            {
                if($_GET["redirect"] == "fgtpwd")
                {
                    // Redirection vers la page d'oubli de mot de passe
                    require_once 'Vue/forgot_password.php';
                }
                else
                {
                    require_once 'Vue/connection.php';
                }
                
            } 
            else
            {
                require_once 'Vue/connection.php';
            }
        }
    ?>
</body>
</php>

