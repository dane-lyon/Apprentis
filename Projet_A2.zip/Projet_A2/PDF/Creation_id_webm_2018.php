<?php
	ob_start();
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1 plus MathML 2.0//EN" "http://www.w3.org/Math/DTD/mathml2/xhtml-math11-f.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!--This file was converted to xhtml by LibreOffice - see http://cgit.freedesktop.org/libreoffice/core/tree/filter/source/xslt for the code.-->

<head profile="http://dublincore.org/documents/dcmi-terms/">
	<meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8" />
	<title xml:lang="en-US">Courrier_id_ouverture</title>
	<meta name="DCTERMS.title" content="Courrier_id_ouverture" xml:lang="en-US" />
	<meta name="DCTERMS.language" content="en-US" scheme="DCTERMS.RFC4646" />
	<meta name="DCTERMS.source" content="http://xml.openoffice.org/odf2xhtml" />
	<meta name="DCTERMS.issued" content="2018-06-21T13:36:16.949916896" scheme="DCTERMS.W3CDTF" />
	<meta name="DCTERMS.provenance" content="" xml:lang="en-US" />
	<meta name="DCTERMS.subject" content="," xml:lang="en-US" />
	<link rel="schema.DC" href="http://purl.org/dc/elements/1.1/" hreflang="en" />
	<link rel="schema.DCTERMS" href="http://purl.org/dc/terms/" hreflang="en" />
	<link rel="schema.DCTYPE" href="http://purl.org/dc/dcmitype/" hreflang="en" />
	<link rel="schema.DCAM" href="http://purl.org/dc/dcam/" hreflang="en" />
	<style type="text/css">
		@page {}

		table {
			border-collapse: collapse;
			border-spacing: 0;
			empty-cells: show
		}

		td,
		th {
			vertical-align: top;
			font-size: 12pt;
		}

		h1,
		h2,
		h3,
		h4,
		h5,
		h6 {
			clear: both
		}

		ol,
		ul {
			margin: 0;
			padding: 0;
		}

		li {
			list-style: none;
			margin: 0;
			padding: 0;
		}

		< !-- "li span.odfLiEnd" - IE 7 issue-->li span. {
			clear: both;
			line-height: 0;
			width: 0;
			height: 0;
			margin: 0;
			padding: 0;
		}

		span.footnodeNumber {
			padding-right: 1em;
		}

		span.annotation_style_by_filter {
			font-size: 95%;
			font-family: Arial;
			background-color: #fff000;
			margin: 0;
			border: 0;
			padding: 0;
		}

		* {
			margin: 0;
		}

		.fr1 {
			font-size: 12pt;
			
			vertical-align: top;
			writing-mode: lr-tb;
			margin-left: 0.319cm;
			margin-right: 0.319cm;
			padding: 0.002cm;
			border-style: none;
		}

		.fr2 {
			font-size: 12pt;
			
			vertical-align: top;
			writing-mode: lr-tb;
			margin-left: 0.319cm;
			margin-right: 0.319cm;
			background-color: #ffffff;
			padding: 0.002cm;
			border-style: none;
		}

		.fr3 {
			font-size: 12pt;
			
			text-align: center;
			vertical-align: top;
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: 0cm;
			padding: 0.002cm;
			border-style: none;
		}

		.fr4 {
			font-size: 12pt;
			
			vertical-align: top;
			writing-mode: lr-tb;
		}

		.P1 {
			font-size: 12pt;
			
			writing-mode: lr-tb;
		}

		.P10 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
		}

		.P11 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
			font-weight: normal;
		}

		.P12 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
			font-weight: normal;
		}

		.P13 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
			font-style: italic;
			font-weight: normal;
		}

		.P14 {
			font-size: 8pt;
			
			writing-mode: lr-tb;
		}

		.P15 {
			font-size: 9.5pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
			font-weight: bold;
		}

		.P16 {
			font-size: 8pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
		}

		.P17 {
			font-size: 8pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
		}

		.P18 {
			font-size: 8pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
		}

		.P19 {
			font-size: 8pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
		}

		.P2 {
			font-size: 12pt;
			
			writing-mode: lr-tb;
			font-weight: bold;
		}

		.P20 {
			font-size: 8pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
			font-weight: bold;
		}

		.P21 {
			font-size: 8pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
			font-weight: bold;
		}

		.P22 {
			font-size: 12pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
		}

		.P23 {
			font-size: 12pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
		}

		.P24 {
			font-size: 12pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			text-indent: 0cm;
		}

		.P25 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
		}

		.P26 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
		}

		.P27 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
		}

		.P28 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: right ! important;
			text-indent: 0cm;
		}

		.P29 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
		}

		.P30 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
		}

		.P31 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
		}

		.P32 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
			background-color: transparent;
		}

		.P33 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
			font-weight: bold;
		}

		.P34 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
			color: #0000ff;
			font-weight: normal;
			background-color: transparent;
		}

		.P35 {
			font-size: 12pt;
			
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
		}

		.P36 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
			text-align: justify ! important;
		}

		.P37 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
			text-align: justify ! important;
		}

		.P38 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
			text-align: justify ! important;
			background-color: transparent;
		}

		.P39 {
			color: #808080;
			font-size: 95%;
			font-style: italic;
			font-weight: bold;
			margin-bottom: 0.212cm;
			margin-top: 0.212cm;
			
			writing-mode: lr-tb;
		}

		.P4 {
			font-size: 12pt;
			
			writing-mode: lr-tb;
		}

		.P6 {
			font-size: 12pt;
			
			writing-mode: lr-tb;
			text-align: right ! important;
		}

		.P7 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
		}

		.P8 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
		}

		.P9 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
		}

		.Tableau1 {
			width: 18.593cm;
			margin-left: 0.009cm;
			margin-right: auto;
			writing-mode: lr-tb;
		}

		.Tableau2 {
			width: 13.361cm;
			float: none;
			writing-mode: lr-tb;
		}

		.Tableau1_A1 {
			vertical-align: top;
			padding-left: 0.191cm;
			padding-right: 0.191cm;
			padding-top: 0cm;
			padding-bottom: 0cm;
			border-style: none;
			writing-mode: lr-tb;
		}

		.Tableau2_A1 {
			padding: 0.097cm;
			border-left-width: thin;
			border-left-style: solid;
			border-left-color: #000000;
			border-right-style: none;
			border-top-width: thin;
			border-top-style: solid;
			border-top-color: #000000;
			border-bottom-width: thin;
			border-bottom-style: solid;
			border-bottom-color: #000000;
		}

		.Tableau2_A2 {
			padding: 0.097cm;
			border-left-width: thin;
			border-left-style: solid;
			border-left-color: #000000;
			border-right-style: none;
			border-top-style: none;
			border-bottom-width: thin;
			border-bottom-style: solid;
			border-bottom-color: #000000;
		}

		.Tableau2_B1 {
			padding: 0.097cm;
			border-width: thin;
			border-style: solid;
			border-color: #000000;
		}

		.Tableau2_B2 {
			padding: 0.097cm;
			border-left-width: thin;
			border-left-style: solid;
			border-left-color: #000000;
			border-right-width: thin;
			border-right-style: solid;
			border-right-color: #000000;
			border-top-style: none;
			border-bottom-width: thin;
			border-bottom-style: solid;
			border-bottom-color: #000000;
		}

		.Tableau1_A {
			width: 3.425cm;
		}

		.Tableau1_B {
			width: 1.425cm;
		}

		.Tableau1_C {
			width: 7.209cm;
		}

		.Tableau1_D {
			width: 6.533cm;
		}

		.Tableau2_A {
			width: 4.002cm;
		}

		.Tableau2_B {
			width: 9.359cm;
		}

		.Internet_20_link {
			color: #0000ff;
			text-decoration: underline;
		}

		.T1 {
			color: #333333;
			
			font-size: 8pt;
		}

		.T11 {
			color: #0000ff;
			font-weight: normal;
			background-color: transparent;
		}

		.T12 {
			color: #0000ff;
			font-weight: bold;
		}

		.T2 {
			color: #333333;
			
			font-size: 8pt;
		}

		.T3 {
			color: #333333;
			
			font-size: 8pt;
		}

		.T4 {
			color: #333333;
			
			font-size: 8pt;
		}

		.T6 {
			font-weight: bold;
		}

		.T9 {
			background-color: transparent;
		}

		< !-- ODF styles with no properties representable as CSS -->.Tableau1.1 .Tableau1.2 .Tableau1.3 .T10 .T13 .T14 .T15 .T16 .T5 .T7 .T8 {}
	</style>
</head>

<body dir="ltr" style="max-width:21.001cm;margin-top:1.249cm; margin-bottom:1.268cm; margin-left:0.635cm; margin-right:0.681cm; ">
	<table border="0" cellspacing="0" cellpadding="0" class="Tableau1">
			<col width="150" />
			<col width="62" />
			<col width="315" />
			<col width="285" />
		<tr class="Tableau11">
			<td style="text-align:left;width:3.425cm; " class="Tableau1_A1">
				<p class="P23"> </p>
				<p class="P4"> </p>
				<p class="P4"> </p>
				<p class="P4"> </p>
				<p class="P6"> </p>
			</td>
			<td rowspan="3" style="text-align:left;width:1.425cm; " class="Tableau1_A1">
				<p class="P24"> </p>
			</td>
			<td style="text-align:left;width:7.209cm; " class="Tableau1_A1">
				<p class="P8"> </p>
			</td>
			<td style="text-align:left;width:6.533cm; " class="Tableau1_A1">
				<p class="P7">
					<span class="T5">Lyon, le </span>
					<span class="T5">
						<span title="date">21 juin 2018</span>
					</span>
				</p>
				<p class="P9"> </p>
				<p class="P9"> </p>
				<p class="P9">L
					<span class="T13">e webmestre des sites pédagogiques</span>
				</p>
				<p class="P9"> </p>
				<p class="P10">à
					<span class="T6"> </span>
					<span class="T6">&lt;Webmestre&gt;</span>
				</p>
				<p class="P12">Webmestre du site &lt;Article2&gt; &lt;Nom_etab&gt;</p>
				<p class="P11"> </p>
			</td>
		</tr>
		<tr class="Tableau12">
			<td rowspan="2" style="text-align:left;width:3.425cm; " class="Tableau1_A1">
				<p class="P15">Rectorat</p>
				<p class="P17">
					<a id="Texte5" />
				</p>
				<p class="P17">DANE</p>
				<p class="P22">
					<span class="T1">Délégation Académique au Numérique pour l’</span>
					<span class="T4">É</span>
					<span class="T1">ducation</span>
				</p>
				<p class="P17"> </p>
				<p class="P18">Affaire suivie par</p>
				<p class="P16">V<span class="T15">irginie Favrat</span>
				</p>
				<p class="P18"> Téléphone</p>
				<p class="P18">04 72 80 66<span class="T15">16</span>
				</p>
				<p class="P17">Télécopie</p>
				<p class="P17">04 72 80 66 07</p>
				<p class="P17">Courriel</p>
				<p class="P22">
					<span class="T1">dan</span>
					<span class="T2">e-</span>
					<span class="T3">webmestre</span>
					<span class="T2">@ac-lyon.fr</span>
				</p>
				<p class="P20"> </p>
				<p class="P20">Adresse postale</p>
				<p class="P21">92, rue de Marseille</p>
				<p class="P21">BP 7227</p>
				<p class="P20">69354 LYON cedex 07</p>
				<p class="P20"> </p>
				<p class="P19">Locaux site Croix Rousse</p>
				<p class="P19">47, rue Philippe de Lassalle</p>
				<p class="P19">69004 Lyon</p>
				<p class="P20"> </p>
				<p class="P20">www.ac-lyon.fr</p>
				<p class="P4"> </p>
			</td>
			<td colspan="2" style="text-align:left;width:7.209cm; " class="Tableau1_A1">
				<p class="P13">
					<span class="T6">Objet </span>: envoi de
					<span class="T13">vos</span> identifiant
					<span class="T14">s</span> pour gérer
					<span class="T8">le</span> site
					<span class="T7">web de votre </span>
					<span class="T7">&lt;Etab&gt;</span>
				</p>
			</td>
		</tr>
		<tr class="Tableau13">
			<td colspan="2" style="text-align:left;width:7.209cm; " class="Tableau1_A1">
				<p class="P32">&lt;Civ_webm&gt;,</p>
				<p class="P27"> </p>
				<h4 class="P39">
					<a id="a__Accès_au_site_public">
						<span/>
					</a>Accès au site public</h4>
				<p class="P30">Dans un navigateur, taper l'adresse
					<a href="./../../../../../home/dane/Documents/Courriers_emis/2014-2015/%3CPseudo_alias%3E"
					 class="Internet_20_link">
						<span class="T12">&lt;Site_public&gt;</span>
					</a>
					<span class="T12"> </span>.
					<span class="T11"> </span>
				</p>
				<p class="P35"> </p>
				<h4 class="P39">
					<a id="a__Accès_à_l'interface_privée">
						<span/>
					</a>Accès à l'interface privée</h4>
				<p class="P30">Elle permet
					<span class="T10">toute </span>la gestion du site (sauf quelques tâches d'un niveau plus avancé) et la rédaction d'articles.</p>
				<p class="P30">Merci de privilégier cette méthode pour gérer votre site sauf si vous avez des connaissances avancées.</p>
				<p class="P30">A la création du site, le webmestre a un compte personnel qui lui permet de créer les comptes des auteurs
					<span class="T10">(</span>et administrateurs si besoin) et de gérer le site.</p>
				<p class="P30"> </p>
				<table border="0" cellspacing="0" cellpadding="0" class="Tableau2">
						<col width="175" />
						<col width="409" />
					<tr>
						<td style="text-align:left;width:4.002cm; " class="Tableau2_A1">
							<p class="P36">Adresse</p>
						</td>
						<td style="text-align:left;width:9.359cm; " class="Tableau2_B1">
							<p class="P34">
								<a href="./../../../../../home/vfavrat/Serveurs_pedago/Creation_sites_dockers/%3CSite_prive%3E" class="Internet_20_link">&lt;Site_prive&gt;</a>
							</p>
						</td>
					</tr>
					<tr>
						<td style="text-align:left;width:4.002cm; " class="Tableau2_A2">
							<p class="P37">Identifiant / login</p>
						</td>
						<td style="text-align:left;width:9.359cm; " class="Tableau2_B2">
							<p class="P38">&lt;Login_webmestre&gt;</p>
						</td>
					</tr>
					<tr>
						<td style="text-align:left;width:4.002cm; " class="Tableau2_A2">
							<p class="P37">Mot de passe</p>
						</td>
						<td style="text-align:left;width:9.359cm; " class="Tableau2_B2">
							<p class="P38">&lt;Mdp_webmestre&gt;</p>
						</td>
					</tr>
				</table>
				<p class="P30"> </p>
				<p class="P29">Bien entendu, ce courrier doit rester
					<span class="T6">confidentiel</span> et ê
					<span class="T16">tre </span>c
					<span class="T6">onservé de façon sécurisée.</span>
				</p>
				<p class="P33"> </p>
				<p class="P29">Je reste à votre disposition pour tout renseignement complémentaire.</p>
				<p class="P31">Je vous prie d'agréer, &lt;Civ_webm&gt;
					<span class="T9">,</span> l'expression de mes sincères salutations.</p>
				<p class="P25"> </p>
				<p class="P25"> </p>
				<p class="P26"> </p>
				<p class="P28">Virginie Favrat</p>
				<p class="P28">DANE</p>
				<p class="P28">Webmestre des sites pédagogiques</p>
				<!--Next 'div' was a 'text:p'.-->
				<div class="P28">
					<!--Next 'div' is emulating the top hight of a draw:frame.-->
					<div style="height:0.31cm;"> </div>
					<!--Next '
			div' is a draw:frame.
		-->
					<div style="height:3.778cm;width:5.463cm; padding:0;  float:left; position:relative; left:7,941cm; " class="fr4" id="Image4">
						
					</div>
				</div>
				<div style="clear:both; line-height:0; width:0; height:0; margin:0; padding:0;"> </div>
			</td>
		</tr>
	</table>
	<p class="P14"> </p>
</body>

</html>

<?php
	$content = ob_get_clean();
	require('../Model/html2pdf/html2pdf.class.php');
	try{
		$pdf = new HTML2PDF('P','A4','fr');
		$pdf->writeHTML($content);
		$pdf->Output('test.pdf');
	}catch(HTML2PDF_exception $e){
		die($e);
	}
?>