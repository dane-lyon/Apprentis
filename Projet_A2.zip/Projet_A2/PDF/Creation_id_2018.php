<?php
	ob_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1 plus MathML 2.0//EN" "http://www.w3.org/Math/DTD/mathml2/xhtml-math11-f.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!--This file was converted to xhtml by LibreOffice - see http://cgit.freedesktop.org/libreoffice/core/tree/filter/source/xslt for the code.-->

<head profile="http://dublincore.org/documents/dcmi-terms/">
	<meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8" />
	<title xml:lang="en-US">Courrier_id_ouverture</title>
	<meta name="DCTERMS.title" content="Courrier_id_ouverture" xml:lang="en-US" />
	<meta name="DCTERMS.language" content="en-US" scheme="DCTERMS.RFC4646" />
	<meta name="DCTERMS.source" content="http://xml.openoffice.org/odf2xhtml" />
	<meta name="DCTERMS.issued" content="2018-06-21T13:35:30.777956549" scheme="DCTERMS.W3CDTF" />
	<meta name="DCTERMS.provenance" content="" xml:lang="en-US" />
	<meta name="DCTERMS.subject" content="," xml:lang="en-US" />
	<link rel="schema.DC" href="http://purl.org/dc/elements/1.1/" hreflang="en" />
	<link rel="schema.DCTERMS" href="http://purl.org/dc/terms/" hreflang="en" />
	<link rel="schema.DCTYPE" href="http://purl.org/dc/dcmitype/" hreflang="en" />
	<link rel="schema.DCAM" href="http://purl.org/dc/dcam/" hreflang="en" />
	<style type="text/css">
		@page {}

		table {
			border-collapse: collapse;
			border-spacing: 0;
			empty-cells: show
		}

		td,
		th {
			vertical-align: top;
			font-size: 12pt;
		}

		h1,
		h2,
		h3,
		h4,
		h5,
		h6 {
			clear: both
		}

		ol,
		ul {
			margin: 0;
			padding: 0;
		}

		li {
			list-style: none;
			margin: 0;
			padding: 0;
		}

		< !-- "li span.odfLiEnd" - IE 7 issue-->li span. {
			clear: both;
			line-height: 0;
			width: 0;
			height: 0;
			margin: 0;
			padding: 0;
		}

		span.footnodeNumber {
			padding-right: 1em;
		}

		span.annotation_style_by_filter {
			font-size: 95%;
			font-family: Arial;
			background-color: #fff000;
			margin: 0;
			border: 0;
			padding: 0;
		}

		* {
			margin: 0;
		}

		.fr1 {
			font-size: 12pt;
			font-family: Liberation Serif;
			vertical-align: top;
			writing-mode: lr-tb;
			margin-left: 0.319cm;
			margin-right: 0.319cm;
			padding: 0.002cm;
			border-style: none;
		}

		.fr2 {
			font-size: 12pt;
			font-family: Liberation Serif;
			vertical-align: top;
			writing-mode: lr-tb;
			margin-left: 0.319cm;
			margin-right: 0.319cm;
			background-color: #ffffff;
			padding: 0.002cm;
			border-style: none;
		}

		.fr3 {
			font-size: 12pt;
			font-family: Liberation Serif;
			text-align: center;
			vertical-align: top;
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: 0cm;
			padding: 0.002cm;
			border-style: none;
		}

		.fr4 {
			font-size: 12pt;
			font-family: Liberation Serif;
			vertical-align: top;
			writing-mode: lr-tb;
		}

		.P1 {
			font-size: 12pt;
			font-family: Times New Roman;
			writing-mode: lr-tb;
		}

		.P10 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
		}

		.P11 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
		}

		.P12 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
		}

		.P13 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
		}

		.P14 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
		}

		.P15 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
		}

		.P16 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			font-style: italic;
			font-weight: normal;
		}

		.P17 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			font-weight: normal;
		}

		.P18 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			font-weight: normal;
		}

		.P19 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			background-color: #ffff00;
		}

		.P2 {
			font-size: 12pt;
			font-family: Times New Roman;
			writing-mode: lr-tb;
			font-weight: bold;
		}

		.P20 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
		}

		.P21 {
			font-size: 8pt;
			font-family: Times New Roman;
			writing-mode: lr-tb;
		}

		.P22 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			color: #000000;
		}

		.P23 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			color: #000000;
		}

		.P24 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			color: #000000;
		}

		.P25 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			color: #000000;
		}

		.P26 {
			font-size: 9.5pt;
			font-family: Arial Narrow;
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
			font-weight: bold;
		}

		.P27 {
			font-size: 9.5pt;
			font-family: Arial Narrow;
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
			font-weight: bold;
		}

		.P28 {
			font-size: 8pt;
			font-family: Arial Narrow;
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
		}

		.P29 {
			font-size: 8pt;
			font-family: Arial Narrow;
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
		}

		.P30 {
			font-size: 8pt;
			font-family: Arial Narrow;
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
		}

		.P31 {
			font-size: 8pt;
			font-family: Arial Narrow;
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
		}

		.P32 {
			font-size: 8pt;
			font-family: Arial Narrow;
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
		}

		.P33 {
			font-size: 8pt;
			font-family: Arial Narrow;
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
		}

		.P34 {
			font-size: 8pt;
			font-family: Arial Narrow;
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
			font-weight: bold;
		}

		.P35 {
			font-size: 8pt;
			font-family: Arial Narrow;
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
			font-weight: bold;
		}

		.P36 {
			font-size: 12pt;
			font-family: Times New Roman;
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
		}

		.P37 {
			font-size: 12pt;
			font-family: Times New Roman;
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
		}

		.P38 {
			font-size: 12pt;
			font-family: Times New Roman;
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
		}

		.P39 {
			font-size: 12pt;
			font-family: Times New Roman;
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
		}

		.P4 {
			font-size: 12pt;
			font-family: Times New Roman;
			writing-mode: lr-tb;
		}

		.P40 {
			font-size: 12pt;
			font-family: Times New Roman;
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			text-indent: 0cm;
		}

		.P41 {
			font-size: 12pt;
			font-family: Times New Roman;
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			text-indent: 0cm;
		}

		.P42 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
		}

		.P43 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
		}

		.P44 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
		}

		.P45 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
		}

		.P46 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: right ! important;
			text-indent: 0cm;
		}

		.P47 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
		}

		.P48 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
		}

		.P49 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
		}

		.P50 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: left ! important;
			text-indent: 0cm;
		}

		.P51 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
			background-color: transparent;
		}

		.P52 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
			font-weight: bold;
			background-color: #ffff00;
		}

		.P53 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
		}

		.P54 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			line-height: 100%;
			text-align: justify ! important;
			text-indent: 0cm;
			color: #000000;
		}

		.P55 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
			color: #0000ff;
			font-weight: normal;
			background-color: transparent;
		}

		.P56 {
			font-size: 10pt;
			line-height: 120%;
			margin-bottom: 0.247cm;
			margin-top: 0cm;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
		}

		.P57 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			text-align: justify ! important;
		}

		.P58 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			text-align: justify ! important;
		}

		.P59 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			text-align: justify ! important;
		}

		.P6 {
			font-size: 12pt;
			font-family: Times New Roman;
			writing-mode: lr-tb;
			text-align: right ! important;
		}

		.P60 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			text-align: justify ! important;
		}

		.P61 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			text-align: justify ! important;
			font-weight: bold;
		}

		.P62 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			text-align: justify ! important;
			font-weight: bold;
			background-color: transparent;
		}

		.P63 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			text-align: justify ! important;
			background-color: transparent;
		}

		.P64 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			text-align: justify ! important;
			background-color: transparent;
		}

		.P65 {
			font-size: 10pt;
			line-height: 120%;
			margin-bottom: 0.247cm;
			margin-top: 0cm;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			color: #000000;
		}

		.P66 {
			font-size: 10pt;
			line-height: 120%;
			margin-bottom: 0.247cm;
			margin-top: 0cm;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			color: #ce181e;
			font-style: italic;
		}

		.P67 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			text-align: justify ! important;
			font-style: normal;
			background-color: transparent;
		}

		.P68 {
			color: #808080;
			font-size: 95%;
			font-style: italic;
			font-weight: bold;
			margin-bottom: 0.212cm;
			margin-top: 0.212cm;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
		}

		.P69 {
			color: #808080;
			font-size: 95%;
			font-style: italic;
			font-weight: bold;
			margin-bottom: 0.212cm;
			margin-top: 0.212cm;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
		}

		.P7 {
			font-size: 12pt;
			font-family: Times New Roman;
			writing-mode: lr-tb;
			text-align: right ! important;
		}

		.P70 {
			color: #000000;
			font-size: 14pt;
			font-weight: bold;
			margin-bottom: 0.212cm;
			margin-top: 0.247cm;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			line-height: 100%;
			text-align: center ! important;
		}

		.P71 {
			color: #000000;
			font-size: 14pt;
			font-weight: bold;
			margin-bottom: 0.212cm;
			margin-top: 0.247cm;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			line-height: 100%;
			text-align: center ! important;
		}

		.P72_borderStart {
			color: #000000;
			font-size: 14pt;
			font-weight: bold;
			margin-top: 0.247cm;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			line-height: 100%;
			text-align: center ! important;
			background-color: transparent;
			padding-bottom: 0.212cm;
			border-bottom-style: none;
		}

		.P72 {
			color: #000000;
			font-size: 14pt;
			font-weight: bold;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			line-height: 100%;
			text-align: center ! important;
			background-color: transparent;
			padding-bottom: 0.212cm;
			padding-top: 0.247cm;
			border-top-style: none;
			border-bottom-style: none;
		}

		.P72_borderEnd {
			color: #000000;
			font-size: 14pt;
			font-weight: bold;
			margin-bottom: 0.212cm;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			line-height: 100%;
			text-align: center ! important;
			background-color: transparent;
			padding-top: 0.247cm;
			border-top-style: none;
		}

		.P73_borderStart {
			color: #000000;
			font-size: 14pt;
			font-weight: bold;
			margin-top: 0.247cm;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			line-height: 100%;
			text-align: center ! important;
			background-color: transparent;
			padding-bottom: 0.212cm;
			border-bottom-style: none;
		}

		.P73 {
			color: #000000;
			font-size: 14pt;
			font-weight: bold;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			line-height: 100%;
			text-align: center ! important;
			background-color: transparent;
			padding-bottom: 0.212cm;
			padding-top: 0.247cm;
			border-top-style: none;
			border-bottom-style: none;
		}

		.P73_borderEnd {
			color: #000000;
			font-size: 14pt;
			font-weight: bold;
			margin-bottom: 0.212cm;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
			line-height: 100%;
			text-align: center ! important;
			background-color: transparent;
			padding-top: 0.247cm;
			border-top-style: none;
		}

		.P8 {
			font-size: 12pt;
			font-family: Times New Roman;
			writing-mode: lr-tb;
		}

		.P9 {
			font-size: 10pt;
			font-family: Liberation Sans;
			writing-mode: lr-tb;
		}

		.Tableau1 {
			width: 18.593cm;
			margin-left: 0.009cm;
			margin-right: auto;
			writing-mode: lr-tb;
		}

		.Tableau2 {
			width: 18.593cm;
			margin-left: 0.009cm;
			margin-right: auto;
			writing-mode: lr-tb;
		}

		.Tableau3 {
			width: 13.361cm;
			float: none;
			writing-mode: lr-tb;
		}

		.Tableau4 {
			width: 13.361cm;
			float: none;
			writing-mode: lr-tb;
		}

		.Tableau5 {
			width: 13.361cm;
			float: none;
			writing-mode: lr-tb;
		}

		.Tableau1_A1 {
			vertical-align: top;
			padding-left: 0.191cm;
			padding-right: 0.191cm;
			padding-top: 0cm;
			padding-bottom: 0cm;
			border-style: none;
			writing-mode: lr-tb;
		}

		.Tableau2_A1 {
			vertical-align: top;
			padding-left: 0.191cm;
			padding-right: 0.191cm;
			padding-top: 0cm;
			padding-bottom: 0cm;
			border-style: none;
			writing-mode: lr-tb;
		}

		.Tableau3_A1 {
			padding: 0.097cm;
			border-left-width: thin;
			border-left-style: solid;
			border-left-color: #000000;
			border-right-style: none;
			border-top-width: thin;
			border-top-style: solid;
			border-top-color: #000000;
			border-bottom-width: thin;
			border-bottom-style: solid;
			border-bottom-color: #000000;
		}

		.Tableau3_A2 {
			padding: 0.097cm;
			border-left-width: thin;
			border-left-style: solid;
			border-left-color: #000000;
			border-right-style: none;
			border-top-style: none;
			border-bottom-width: thin;
			border-bottom-style: solid;
			border-bottom-color: #000000;
		}

		.Tableau3_B1 {
			padding: 0.097cm;
			border-width: thin;
			border-style: solid;
			border-color: #000000;
		}

		.Tableau3_B2 {
			padding: 0.097cm;
			border-left-width: thin;
			border-left-style: solid;
			border-left-color: #000000;
			border-right-width: thin;
			border-right-style: solid;
			border-right-color: #000000;
			border-top-style: none;
			border-bottom-width: thin;
			border-bottom-style: solid;
			border-bottom-color: #000000;
		}

		.Tableau4_A1 {
			padding: 0.097cm;
			border-left-width: thin;
			border-left-style: solid;
			border-left-color: #000000;
			border-right-style: none;
			border-top-width: thin;
			border-top-style: solid;
			border-top-color: #000000;
			border-bottom-width: thin;
			border-bottom-style: solid;
			border-bottom-color: #000000;
		}

		.Tableau4_A2 {
			padding: 0.097cm;
			border-left-width: thin;
			border-left-style: solid;
			border-left-color: #000000;
			border-right-style: none;
			border-top-style: none;
			border-bottom-width: thin;
			border-bottom-style: solid;
			border-bottom-color: #000000;
		}

		.Tableau4_B1 {
			padding: 0.097cm;
			border-width: thin;
			border-style: solid;
			border-color: #000000;
		}

		.Tableau4_B2 {
			padding: 0.097cm;
			border-left-width: thin;
			border-left-style: solid;
			border-left-color: #000000;
			border-right-width: thin;
			border-right-style: solid;
			border-right-color: #000000;
			border-top-style: none;
			border-bottom-width: thin;
			border-bottom-style: solid;
			border-bottom-color: #000000;
		}

		.Tableau5_A1 {
			padding: 0.097cm;
			border-left-width: thin;
			border-left-style: solid;
			border-left-color: #000000;
			border-right-style: none;
			border-top-width: thin;
			border-top-style: solid;
			border-top-color: #000000;
			border-bottom-width: thin;
			border-bottom-style: solid;
			border-bottom-color: #000000;
		}

		.Tableau5_A2 {
			padding: 0.097cm;
			border-left-width: thin;
			border-left-style: solid;
			border-left-color: #000000;
			border-right-style: none;
			border-top-style: none;
			border-bottom-width: thin;
			border-bottom-style: solid;
			border-bottom-color: #000000;
		}

		.Tableau5_B1 {
			padding: 0.097cm;
			border-width: thin;
			border-style: solid;
			border-color: #000000;
		}

		.Tableau5_B2 {
			padding: 0.097cm;
			border-left-width: thin;
			border-left-style: solid;
			border-left-color: #000000;
			border-right-width: thin;
			border-right-style: solid;
			border-right-color: #000000;
			border-top-style: none;
			border-bottom-width: thin;
			border-bottom-style: solid;
			border-bottom-color: #000000;
		}

		.Tableau1_A {
			width: 3.425cm;
		}

		.Tableau1_B {
			width: 1.425cm;
		}

		.Tableau1_C {
			width: 7.209cm;
		}

		.Tableau1_D {
			width: 6.533cm;
		}

		.Tableau2_A {
			width: 3.425cm;
		}

		.Tableau2_B {
			width: 1.425cm;
		}

		.Tableau2_C {
			width: 7.209cm;
		}

		.Tableau2_D {
			width: 6.533cm;
		}

		.Tableau3_A {
			width: 4.002cm;
		}

		.Tableau3_B {
			width: 9.359cm;
		}

		.Tableau4_A {
			width: 3.307cm;
		}

		.Tableau4_B {
			width: 10.054cm;
		}

		.Tableau5_A {
			width: 2.799cm;
		}

		.Tableau5_B {
			width: 10.562cm;
		}

		.Internet_20_link {
			color: #0000ff;
			text-decoration: underline;
		}

		.T1 {
			color: #333333;
			font-family: Arial Narrow;
			font-size: 8pt;
		}

		.T10 {
			font-weight: bold;
		}

		.T14 {
			background-color: transparent;
		}

		.T15 {
			background-color: transparent;
		}

		.T16 {
			background-color: transparent;
		}

		.T17 {
			background-color: transparent;
		}

		.T18 {
			background-color: transparent;
		}

		.T2 {
			color: #333333;
			font-family: Arial Narrow;
			font-size: 8pt;
		}

		.T23 {
			color: #0000ff;
			font-weight: bold;
		}

		.T24 {
			color: #0000ff;
			font-weight: normal;
			background-color: transparent;
		}

		.T27 {
			color: #ce181e;
		}

		.T28 {
			color: #ce181e;
		}

		.T3 {
			color: #333333;
			font-family: Arial Narrow;
			font-size: 8pt;
		}

		.T30 {
			font-style: italic;
		}

		.T32 {
			color: #000000;
			background-color: transparent;
		}

		.T33 {
			color: #000000;
			background-color: transparent;
		}

		.T4 {
			color: #333333;
			font-family: Arial Narrow;
			font-size: 8pt;
		}

		< !-- ODF styles with no properties representable as CSS -->.Tableau1.1 .Tableau1.2 .Tableau1.3 .Tableau2.1 .Tableau2.2 .Tableau2.3 .T11 .T12 .T13 .T19 .T20 .T21 .T22 .T25 .T26 .T29 .T31 .T34 .T5 .T6 .T7 .T8 .T9 {}
	</style>
</head>

<body dir="ltr" style="max-width:21.001cm;margin-top:1.249cm; margin-bottom:1.268cm; margin-left:0.635cm; margin-right:0.681cm; ">
	<table border="0" cellspacing="0" cellpadding="0" class="Tableau1">
			<col width="150" />
			<col width="62" />
			<col width="315" />
			<col width="285" />
		<tr class="Tableau11">
			<td style="text-align:left;width:3.425cm; " class="Tableau1_A1">
				<p class="P37"> </p>
				<p class="P4"> </p>
				<p class="P4"> </p>
				<p class="P4"> </p>
				<p class="P6"> </p>
			</td>
			<td rowspan="3" style="text-align:left;width:1.425cm; " class="Tableau1_A1">
				<p class="P40"> </p>
			</td>
			<td style="text-align:left;width:7.209cm; " class="Tableau1_A1">
				<p class="P10"> </p>
			</td>
			<td style="text-align:left;width:6.533cm; " class="Tableau1_A1">
				<p class="P9">
					<span class="T9">Lyon, le </span>
					<span class="T9">
						<span title="date">21 juin 2018</span>
					</span>
				</p>
				<p class="P13"> </p>
				<p class="P13"> </p>
				<p class="P13">L
					<span class="T5">a webmestre des sites pédagogiques</span>
				</p>
				<p class="P13"> </p>
				<p class="P13">à
					<span class="T10"> </span>
					<span class="T10">&lt;Destinataire&gt;</span>
				</p>
				<p class="P17">&lt;Fonction&gt;</p>
				<p class="P17"> </p>
			</td>
		</tr>
		<tr class="Tableau12">
			<td rowspan="2" style="text-align:left;width:3.425cm; " class="Tableau1_A1">
				<p class="P26">Rectorat</p>
				<p class="P30">
					<a id="Texte5" />
				</p>
				<p class="P30">DANE</p>
				<p class="P36">
					<span class="T1">Délégation Académique au Numérique pour l’</span>
					<span class="T4">É</span>
					<span class="T1">ducation</span>
				</p>
				<p class="P30"> </p>
				<p class="P30">Affaire suivie par</p>
				<p class="P28">V
					<span class="T5">irginie Favrat</span>
				</p>
				<p class="P30"> Téléphone</p>
				<p class="P30">04 72 80 66
					<span class="T5">16</span>
				</p>
				<p class="P30">Télécopie</p>
				<p class="P30">04 72 80 66 07</p>
				<p class="P30">Courriel</p>
				<p class="P36">
					<span class="T1">dan</span>
					<span class="T2">e-</span>
					<span class="T3">webmestre</span>
					<span class="T2">@ac-lyon.fr</span>
				</p>
				<p class="P34"> </p>
				<p class="P34">Adresse postale</p>
				<p class="P34">92, rue de Marseille - BP 7227</p>
				<p class="P34">69354 LYON cedex 07</p>
				<p class="P34"> </p>
				<p class="P32">Locaux site Croix Rousse</p>
				<p class="P32">47, rue Philippe de Lassalle</p>
				<p class="P32">69004 Lyon</p>
				<p class="P34"> </p>
				<p class="P34">www.ac-lyon.fr</p>
				<p class="P4"> </p>
			</td>
			<td colspan="2" style="text-align:left;width:7.209cm; " class="Tableau1_A1">
				<p class="P16">
					<span class="T10">Objet </span>: identifiants pour gérer
					<span class="T12">le</span> site
					<span class="T11">web de votre </span>
					<span class="T11">&lt;Etab&gt;</span>
				</p>
			</td>
		</tr>
		<tr class="Tableau13">
			<td colspan="2" style="text-align:left;width:7.209cm; " class="Tableau1_A1">
				<p class="P51">&lt;Civilite&gt;,</p>
				<p class="P42"> </p>
				<p class="P56">Vous avez demandé l'ouverture d'un espace sur le serveur pédagogique académique pour héberger votre site Web.</p>
				<p class="P53">
					<span class="T8">V</span>
					<span class="T6">ous </span>
					<span class="T7">trouverez</span>
					<span class="T6"> ci-dessous les identifiants pour gérer ce site.</span>
				</p>
				<p class="P45">Bien entendu, ce courrier doit rester
					<span class="T10">confidentiel</span> et ê
					<span class="T13">tre </span>c
					<span class="T10">onservé de façon sécurisée.</span>
				</p>
				<p class="P43"> </p>
				<p class="P45">Nous espérons que la mise en place de ce site répondra à vos attentes et que vous serez satisfait&lt;Accord&gt; de
					<span
					 class="T25">cet outil de communication au service de votre équipe et des usagers.</span>
				</p>
				<p class="P45"> </p>
				<p class="P45">La DANE propose au PAF
					<span class="T13">d</span>
					<span class="T17">es f</span>
					<span class="T14">ormations </span>
					<span class="T18">(</span>
					<span class="T14">gestion et utilisation d'un site Web</span>
					<span class="T18">)</span>
					<span class="T14"> </span>
					<span class="T18">auxquelles</span>
					<span class="T14"> </span>
					<span class="T18">le</span>
					<span class="T14"> webmestre de votre site pourra s</span>
					<span class="T18">'</span>
					<span class="T14">inscrire </span>afin de prendre en main plus rapidement cet outil.
					<span class="T29">(</span>
					<span class="T30">Pour le premier degré, se renseigner auprès du service compétent.</span>
					<span class="T29">)</span>
				</p>
				<p class="P45"> </p>
				<p class="P45">Je reste à votre disposition pour tout renseignement complémentaire.</p>
				<p class="P49">Je vous prie d'agréer, &lt;Civilite&gt;
					<span class="T14">,</span> l'expression de mes sincères salutations.</p>
				<p class="P42"> </p>
				<p class="P42"> </p>
				<p class="P42"> </p>
				<p class="P46">Virginie Favrat</p>
				<p class="P46">DANE</p>
				<!--Next 'div' was a 'text:p'.-->
				<div class="P46">
					<!--Next 'div' is emulating the top hight of a draw:frame.-->
					<div style="height:0.58cm;"> </div>
					<!--Next '
			div' is a draw:frame.
		-->
					<div style="height:3.778cm;width:5.463cm; padding:0;  float:left; position:relative; left:8,02cm; " class="fr4" id="Image3">
					</div>
					<!--Next 'div' added for floating.-->
					<div style="position:relative; left:8,02cm;">Webmestre des sites pédagogiques</div>
				</div>
				<div style="clear:both; line-height:0; width:0; height:0; margin:0; padding:0;"> </div>
				<p class="P50">P.J. :
					<span class="T32">I</span>
					<span class="T33">nformations techniques pour la gestion du site Web </span>
				</p>
			</td>
		</tr>
	</table>
	<p class="P4"> </p>
			<col width="150" />
			<col width="62" />
			<col width="315" />
			<col width="285" />
		<tr class="Tableau21">
			<td style="text-align:left;width:3.425cm; " class="Tableau2_A1">
				<p class="P38"> </p>
				<p class="P8"> </p>
				<p class="P8"> </p>
				<p class="P8"> </p>
				<p class="P7"> </p>
			</td>
			<td rowspan="3" style="text-align:left;width:1.425cm; " class="Tableau2_A1">
				<p class="P41"> </p>
			</td>
			<td style="text-align:left;width:7.209cm; " class="Tableau2_A1">
				<p class="P11"> </p>
			</td>
			<td style="text-align:left;width:6.533cm; " class="Tableau2_A1">
				<p class="P12">
					<span class="T9">Lyon, le </span>
					<span class="T9">
						<span title="date">21 juin 2018</span>
					</span>
				</p>
				<p class="P14"> </p>
				<p class="P14"> </p>
				<p class="P14">L
					<span class="T5">a webmestre des sites pédagogiques</span>
				</p>
				<p class="P14"> </p>
				<p class="P15">à
					<span class="T10"> </span>
					<span class="T10">&lt;Destinataire&gt;</span>
				</p>
				<p class="P18">&lt;Fonction&gt;</p>
				<p class="P19"> </p>
			</td>
		</tr>
		<tr class="Tableau22">
			<td rowspan="2" style="text-align:left;width:3.425cm; " class="Tableau2_A1">
				<p class="P27">Rectorat</p>
				<p class="P31">
					<a id="Texte52" />
				</p>
				<p class="P31">DANE</p>
				<p class="P39">
					<span class="T1">Délégation Académique au Numérique pour l’</span>
					<span class="T4">É</span>
					<span class="T1">ducation</span>
				</p>
				<p class="P31"> </p>
				<p class="P31">Affaire suivie par</p>
				<p class="P29">V
					<span class="T5">irginie Favrat</span>
				</p>
				<p class="P31"> Téléphone</p>
				<p class="P31">04 72 80 66
					<span class="T5">16</span>
				</p>
				<p class="P31">Télécopie</p>
				<p class="P31">04 72 80 66 07</p>
				<p class="P31">Courriel</p>
				<p class="P39">
					<span class="T1">dan</span>
					<span class="T2">e-</span>
					<span class="T3">webmestre</span>
					<span class="T2">@ac-lyon.fr</span>
				</p>
				<p class="P35"> </p>
				<p class="P35">Adresse postale</p>
				<p class="P35">92, rue de Marseille - BP 7227</p>
				<p class="P35">69354 LYON cedex 07</p>
				<p class="P35"> </p>
				<p class="P33">Locaux site Croix Rousse</p>
				<p class="P33">47, rue Philippe de Lassalle</p>
				<p class="P33">69004 Lyon</p>
				<p class="P35"> </p>
				<p class="P35">www.ac-lyon.fr</p>
				<p class="P8"> </p>
			</td>
			<td colspan="2" style="text-align:left;width:7.209cm; " class="Tableau2_A1">
				<h3 class="P70">
					<a id="a__Informations_techniques_pour_la_gestion">
						<span/>
					</a>
					<span class="T15">I</span>
					<span class="T16">nformations techniques pour la gestion</span>
				</h3>
				<h3 class="P72">
					<a id="a__du_site_Web__Article2___Etab_">
						<span/>
					</a>du site Web &lt;Article2&gt; &lt;Etab&gt;</h3>
			</td>
		</tr>
		<tr class="Tableau23">
			<td colspan="2" style="text-align:left;width:7.209cm; " class="Tableau2_A1">
				<h4 class="P68">
					<a id="a__Accès_au_site_public">
						<span/>
					</a>Accès au site public</h4>
				<p class="P48">Dans un navigateur, taper l'adresse
					<a href="./../../../../../home/dane/Documents/Courriers_emis/2014-2015/%3CPseudo_alias%3E"
					 class="Internet_20_link">
						<span class="T23">&lt;Site_public&gt;</span>
					</a>
					<span class="T23"> </span>.
					<span class="T24"> </span>
				</p>
				<p class="P52"> </p>
				<h4 class="P68">
					<a id="a__Accès_à_l'interface_privée">
						<span/>
					</a>Accès à l'interface privée</h4>
				<p class="P47">Elle permet
					<span class="T19">toute </span>la gestion du site (sauf quelques tâches d'un niveau plus avancé) et la rédaction d'articles.</p>
				<p class="P47">Merci de privilégier cette méthode pour gérer votre site sauf si vous avez des connaissances avancées.</p>
				<p class="P47">A la création du site, le webmestre a un compte personnel qui lui permet de créer les comptes des auteurs
					<span class="T19">(</span>et administrateurs si besoin) et de gérer le site.</p>
				<p class="P47">Le compte ci-dessous n'est à utiliser que de façon exceptionnelle sans changer le mot de passe, sauf avec l'accord de
					la DANE.</p>
				<p class="P54">Il permet au directeur de publication de créer un compte personnel pour un nouveau webmestre.</p>
				<p class="P54"> </p>
				<table border="0" cellspacing="0" cellpadding="0" class="Tableau3">
						<col width="175" />
						<col width="409" />
					<tr>
						<td style="text-align:left;width:4.002cm; " class="Tableau3_A1">
							<p class="P57">Adresse</p>
						</td>
						<td style="text-align:left;width:9.359cm; " class="Tableau3_B1">
							<p class="P55">
								<a href="./../../../../../home/dane/Documents/projet_AP_doc/%3CSite_prive%3E" class="Internet_20_link">&lt;Site_prive&gt;</a>
							</p>
						</td>
					</tr>
					<tr>
						<td style="text-align:left;width:4.002cm; " class="Tableau3_A2">
							<p class="P58">Identifiant / login</p>
						</td>
						<td style="text-align:left;width:9.359cm; " class="Tableau3_B2">
							<p class="P63">&lt;Identifiant&gt;</p>
						</td>
					</tr>
					<tr>
						<td style="text-align:left;width:4.002cm; " class="Tableau3_A2">
							<p class="P58">Mot de passe</p>
						</td>
						<td style="text-align:left;width:9.359cm; " class="Tableau3_B2">
							<p class="P63">&lt;Mdp&gt;</p>
						</td>
					</tr>
				</table>
				<p class="P47"> </p>
				<h4 class="P68">
					<a id="a__Dépôt_de_fichiers_sur_le_serveur__avancé_">
						<span/>
					</a>
					<span class="T20">Dépôt</span> de fichiers
					<span class="T20">sur le serveur (</span>
					<span class="T28">avancé</span>
					<span class="T20">)</span>
				</h4>
				<p class="P65">A l'aide d'un logiciel tel que File Zilla ou WinSCP</p>
				<p class="P66">
					<span class="T10">Attention </span>: il est absolument interdit de créer des dossiers. Les fichiers ne pourront être stockés que dans
					les dossiers prévus dans l’arborescence de SPIP. Sinon ils seront perdus lors des mises à jour du site.</p>
				<table border="0"
				 cellspacing="0" cellpadding="0" class="Tableau4">
						<col width="145" />
						<col width="439" />
					<tr>
						<td style="text-align:left;width:3.307cm; " class="Tableau4_A1">
							<p class="P58">Protocole</p>
						</td>
						<td style="text-align:left;width:10.054cm; " class="Tableau4_B1">
							<p class="P61">SFTP</p>
						</td>
					</tr>
					<tr>
						<td style="text-align:left;width:3.307cm; " class="Tableau4_A2">
							<p class="P58">Serveur
								<span class="T22">(hôte)</span>
							</p>
						</td>
						<td style="text-align:left;width:10.054cm; " class="Tableau4_B2">
							<p class="P62">&lt;Serveur&gt;</p>
						</td>
					</tr>
					<tr>
						<td style="text-align:left;width:3.307cm; " class="Tableau4_A2">
							<p class="P58">Port</p>
						</td>
						<td style="text-align:left;width:10.054cm; " class="Tableau4_B2">
							<p class="P58">22
								<span class="T26">22</span>
							</p>
						</td>
					</tr>
					<tr>
						<td style="text-align:left;width:3.307cm; " class="Tableau4_A2">
							<p class="P58">Identifiant / login</p>
						</td>
						<td style="text-align:left;width:10.054cm; " class="Tableau4_B2">
							<p class="P63">&lt;Identifiant&gt;</p>
						</td>
					</tr>
					<tr>
						<td style="text-align:left;width:3.307cm; " class="Tableau4_A2">
							<p class="P58">Mot de passe</p>
						</td>
						<td style="text-align:left;width:10.054cm; " class="Tableau4_B2">
							<p class="P63">&lt;Mdp&gt;</p>
						</td>
					</tr>
					<tr>
						<td style="text-align:left;width:3.307cm; " class="Tableau4_A2">
							<p class="P60">Dossier</p>
						</td>
						<td style="text-align:left;width:10.054cm; " class="Tableau4_B2">
							<p class="P67">/var/www/html/spip</p>
						</td>
					</tr>
				</table>
</body>

</html>


<?php
	$content = ob_get_clean();
	require('../Model/html2pdf/html2pdf.class.php');
	try{
		$pdf = new HTML2PDF('P','A4','fr');
		$pdf->writeHTML($content);
		$pdf->Output('test.pdf');
	}catch(HTML2PDF_exception $e){
		die($e);
	}
?>