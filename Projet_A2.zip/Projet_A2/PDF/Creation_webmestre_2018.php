<?php
	ob_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1 plus MathML 2.0//EN" "http://www.w3.org/Math/DTD/mathml2/xhtml-math11-f.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!--This file was converted to xhtml by LibreOffice - see http://cgit.freedesktop.org/libreoffice/core/tree/filter/source/xslt for the code.-->

<head profile="http://dublincore.org/documents/dcmi-terms/">
	<meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8" />
	<title xml:lang="en-US">Courrier_id_ouverture</title>
	<meta name="DCTERMS.title" content="Courrier_id_ouverture" xml:lang="en-US" />
	<meta name="DCTERMS.language" content="en-US" scheme="DCTERMS.RFC4646" />
	<meta name="DCTERMS.source" content="http://xml.openoffice.org/odf2xhtml" />
	<meta name="DCTERMS.creator" content="Virginie Favrat" />
	<meta name="DCTERMS.issued" content="2017-12-07T12:51:34.320248763" scheme="DCTERMS.W3CDTF" />
	<meta name="DCTERMS.contributor" content="Virginie Favrat" />
	<meta name="DCTERMS.modified" content="2017-12-07T14:46:49.748530607" scheme="DCTERMS.W3CDTF" />
	<meta name="DCTERMS.provenance" content="" xml:lang="en-US" />
	<meta name="DCTERMS.subject" content="," xml:lang="en-US" />
	<link rel="schema.DC" href="http://purl.org/dc/elements/1.1/" hreflang="en" />
	<link rel="schema.DCTERMS" href="http://purl.org/dc/terms/" hreflang="en" />
	<link rel="schema.DCTYPE" href="http://purl.org/dc/dcmitype/" hreflang="en" />
	<link rel="schema.DCAM" href="http://purl.org/dc/dcam/" hreflang="en" />
	<style type="text/css">
		@page {}

		table {
			border-collapse: collapse;
			border-spacing: 0;
			empty-cells: show
		}

		td,
		th {
			vertical-align: top;
			font-size: 12pt;
		}

		h1,
		h2,
		h3,
		h4,
		h5,
		h6 {
			clear: both
		}

		ol,
		ul {
			margin: 0;
			padding: 0;
		}

		li {
			list-style: none;
			margin: 0;
			padding: 0;
		}

		< !-- "li span.odfLiEnd" - IE 7 issue-->li span. {
			clear: both;
			line-height: 0;
			width: 0;
			height: 0;
			margin: 0;
			padding: 0;
		}

		span.footnodeNumber {
			padding-right: 1em;
		}

		span.annotation_style_by_filter {
			font-size: 95%;
			font-family: Arial;
			background-color: #fff000;
			margin: 0;
			border: 0;
			padding: 0;
		}

		* {
			margin: 0;
		}

		.fr1 {
			font-size: 12pt;
			
			vertical-align: top;
			writing-mode: lr-tb;
			margin-left: 0.319cm;
			margin-right: 0.319cm;
			background-color: #ffffff;
			padding: 0.002cm;
			border-style: none;
		}

		.fr2 {
			font-size: 12pt;
			
			text-align: center;
			vertical-align: top;
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: 0cm;
			padding: 0.002cm;
			border-style: none;
		}

		.fr3 {
			font-size: 12pt;
			
			vertical-align: top;
			writing-mode: lr-tb;
			margin-left: 0.319cm;
			margin-right: 0.319cm;
			padding: 0.002cm;
			border-style: none;
		}

		.fr4 {
			font-size: 12pt;
			
			vertical-align: top;
			writing-mode: lr-tb;
		}

		.P1 {
			font-size: 12pt;
			
			writing-mode: lr-tb;
		}

		.P10 {
			font-size: 9pt;
			
			writing-mode: lr-tb;
		}

		.P11 {
			font-size: 9pt;
			
			writing-mode: lr-tb;
		}

		.P12 {
			font-size: 9pt;
			
			writing-mode: lr-tb;
		}

		.P13 {
			font-size: 9pt;
			
			writing-mode: lr-tb;
			font-style: italic;
			font-weight: normal;
		}

		.P14 {
			font-size: 8pt;
			
			writing-mode: lr-tb;
		}

		.P15 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
		}

		.P16 {
			font-size: 9pt;
			
			writing-mode: lr-tb;
		}

		.P17 {
			font-size: 9pt;
			
			writing-mode: lr-tb;
		}

		.P18 {
			font-size: 9pt;
			
			writing-mode: lr-tb;
		}

		.P19 {
			font-size: 9pt;
			
			writing-mode: lr-tb;
		}

		.P2 {
			font-size: 12pt;
			
			writing-mode: lr-tb;
			font-weight: bold;
		}

		.P20 {
			font-size: 9.5pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
			font-weight: bold;
		}

		.P21 {
			font-size: 8pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
		}

		.P22 {
			font-size: 8pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
		}

		.P23 {
			font-size: 8pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
		}

		.P24 {
			font-size: 8pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
			font-weight: bold;
		}

		.P25 {
			font-size: 12pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
		}

		.P26 {
			font-size: 12pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
		}

		.P27 {
			font-size: 12pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
		}

		.P28 {
			font-size: 12pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			text-indent: 0cm;
		}

		.P29 {
			font-size: 12pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			text-indent: 0cm;
		}

		.P30 {
			font-size: 9pt;
			
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
			background-color: transparent;
		}

		.P31 {
			font-size: 9pt;
			
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
		}

		.P32 {
			font-size: 9pt;
			
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: right ! important;
			text-indent: 0cm;
		}

		.P33 {
			font-size: 9pt;
			
			writing-mode: lr-tb;
			margin-left: 0.025cm;
			margin-right: 0cm;
			text-align: justify ! important;
			text-indent: 0cm;
		}

		.P34 {
			font-size: 9pt;
			
			writing-mode: lr-tb;
		}

		.P35 {
			font-size: 9pt;
			
			writing-mode: lr-tb;
		}

		.P36 {
			font-size: 9pt;
			
			writing-mode: lr-tb;
		}

		.P37 {
			font-size: 9pt;
			
			writing-mode: lr-tb;
		}

		.P38 {
			font-size: 8pt;
			
			writing-mode: lr-tb;
			margin-left: 0cm;
			margin-right: -0.191cm;
			line-height: 120%;
			text-align: right ! important;
			text-indent: 0cm;
			color: #333333;
		}

		.P39 {
			color: #808080;
			font-size: 10pt;
			font-style: italic;
			font-weight: bold;
			margin-bottom: 0.212cm;
			margin-top: 0.212cm;
			
			writing-mode: lr-tb;
		}

		.P4 {
			font-size: 12pt;
			
			writing-mode: lr-tb;
		}

		.P40_borderStart {
			color: #000000;
			font-size: 14pt;
			font-weight: bold;
			margin-top: 0.247cm;
			
			writing-mode: lr-tb;
			line-height: 100%;
			text-align: center ! important;
			background-color: transparent;
			padding-bottom: 0.212cm;
			border-bottom-style: none;
		}

		.P40 {
			color: #000000;
			font-size: 14pt;
			font-weight: bold;
			
			writing-mode: lr-tb;
			line-height: 100%;
			text-align: center ! important;
			background-color: transparent;
			padding-bottom: 0.212cm;
			padding-top: 0.247cm;
			border-top-style: none;
			border-bottom-style: none;
		}

		.P40_borderEnd {
			color: #000000;
			font-size: 14pt;
			font-weight: bold;
			margin-bottom: 0.212cm;
			
			writing-mode: lr-tb;
			line-height: 100%;
			text-align: center ! important;
			background-color: transparent;
			padding-top: 0.247cm;
			border-top-style: none;
		}

		.P6 {
			font-size: 12pt;
			
			writing-mode: lr-tb;
			text-align: right ! important;
		}

		.P7 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
		}

		.P8 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
		}

		.P9 {
			font-size: 10pt;
			
			writing-mode: lr-tb;
			background-color: #ffff00;
		}

		.Tableau1 {
			width: 18.593cm;
			margin-left: 0.009cm;
			margin-right: auto;
			writing-mode: lr-tb;
		}

		.Tableau2 {
			width: 18.593cm;
			margin-left: 0.009cm;
			margin-right: auto;
			writing-mode: lr-tb;
		}

		.Tableau1_A1 {
			vertical-align: top;
			padding-left: 0.191cm;
			padding-right: 0.191cm;
			padding-top: 0cm;
			padding-bottom: 0cm;
			border-style: none;
			writing-mode: lr-tb;
		}

		.Tableau2_A1 {
			vertical-align: top;
			padding-left: 0.191cm;
			padding-right: 0.191cm;
			padding-top: 0cm;
			padding-bottom: 0cm;
			border-style: none;
			writing-mode: lr-tb;
		}

		.Tableau1_A {
			width: 3.425cm;
		}

		.Tableau1_B {
			width: 1.425cm;
		}

		.Tableau1_C {
			width: 7.209cm;
		}

		.Tableau1_D {
			width: 6.533cm;
		}

		.Tableau2_A {
			width: 3.425cm;
		}

		.Tableau2_B {
			width: 1.425cm;
		}

		.Tableau2_C {
			width: 7.209cm;
		}

		.Tableau2_D {
			width: 6.533cm;
		}

		.Bullet_20_Symbols {
			
		}

		.Internet_20_link {
			color: #0000ff;
			text-decoration: underline;
		}

		.T1 {
			color: #333333;
			
			font-size: 8pt;
		}

		.T12 {
			font-weight: normal;
		}

		.T13 {
			font-weight: normal;
		}

		.T17 {
			font-size: 9pt;
		}

		.T18 {
			font-size: 9pt;
		}

		.T2 {
			color: #333333;
			
			font-size: 8pt;
		}

		.T3 {
			color: #333333;
			
			font-size: 8pt;
		}

		.T4 {
			color: #333333;
			
			font-size: 8pt;
		}

		.T7 {
			font-weight: bold;
		}

		.T8 {
			font-weight: bold;
		}

		< !-- ODF styles with no properties representable as CSS -->.Tableau1.1 .Tableau1.2 .Tableau1.3 .Tableau2.1 .Tableau2.2 .Tableau2.3 .T10 .T11 .T14 .T15 .T16 .T5 .T6 .T9 {}
	</style>
</head>

<body dir="ltr" style="max-width:21.001cm;margin-top:1.249cm; margin-bottom:1.268cm; margin-left:0.635cm; margin-right:0.681cm; ">
	<table border="0" cellspacing="0" cellpadding="0" class="Tableau1">
			<col width="150" />
			<col width="62" />
			<col width="315" />
			<col width="285" />
		<tr class="Tableau11">
			<td style="text-align:left;width:3.425cm; " class="Tableau1_A1">
				<!--Next 'div' was a 'text:p'.-->
				<div class="P26">
					<!--Next '
			div' is a draw:frame.
		-->
					<div style="height:3.436cm;width:4.374cm; padding:0;  float:left; position:relative; left:0cm; top:-0.321cm; " class="fr3"
					 id="Image1">
						
					</div>
				</div>
				<div style="clear:both; line-height:0; width:0; height:0; margin:0; padding:0;"> </div>
			</td>
			<td rowspan="3" style="text-align:left;width:1.425cm; " class="Tableau1_A1">
				<p class="P28"> </p>
			</td>
			<td style="text-align:left;width:7.209cm; " class="Tableau1_A1">
				<p class="P7"> </p>
			</td>
			<td style="text-align:left;width:6.533cm; " class="Tableau1_A1">
				<p class="P10">
					<span class="T6">Lyon, le </span>
					<span class="T6">
						<span title="date">21 juin 2018</span>
					</span>
				</p>
				<p class="P11"> </p>
				<p class="P11">L
					<span class="T5">a webmestre des sites pédagogiques</span>
				</p>
				<p class="P12">
					<span class="T15">au w</span>
					<span class="T13">ebmestre du site</span>
				</p>
			</td>
		</tr>
		<tr class="Tableau12">
			<td rowspan="2" style="text-align:left;width:3.425cm; " class="Tableau1_A1">
				<p class="P20"> </p>
				<p class="P20"> </p>
				<p class="P20"> </p>
				<p class="P20">Rectorat</p>
				<p class="P22">
					<a id="Texte5" />
				</p>
				<p class="P22">DANE</p>
				<p class="P25">
					<span class="T1">Délégation Académique au Numérique pour l’</span>
					<span class="T4">É</span>
					<span class="T1">ducation</span>
				</p>
				<p class="P22"> </p>
				<p class="P22">Affaire suivie par</p>
				<p class="P21">V
					<span class="T5">irginie Favrat</span>
				</p>
				<p class="P22"> Téléphone</p>
				<p class="P22">04 72 80 66
					<span class="T5">16</span>
				</p>
				<p class="P22">Télécopie</p>
				<p class="P22">04 72 80 66 07</p>
				<p class="P22">Courriel</p>
				<p class="P25">
					<span class="T1">dan</span>
					<span class="T2">e-</span>
					<span class="T3">webmestre</span>
					<span class="T2">@ac-lyon.fr</span>
				</p>
				<p class="P24"> </p>
				<p class="P24">Adresse postale</p>
				<p class="P24">92, rue de Marseille - BP 7227</p>
				<p class="P24">69354 LYON cedex 07</p>
				<p class="P24"> </p>
				<p class="P23">Locaux site Croix Rousse</p>
				<p class="P23">47, rue Philippe de Lassalle</p>
				<p class="P23">69004 Lyon</p>
				<p class="P24"> </p>
				<p class="P24">www.ac-lyon.fr</p>
				<p class="P4"> </p>
			</td>
			<td colspan="2" style="text-align:left;width:7.209cm; " class="Tableau1_A1">
				<p class="P13">
					<span class="T7">Objet </span>:
					<span class="T14">quelques conseils</span> pour gérer
					<span class="T10">le</span> site
					<span class="T9">web</span>
				</p>
			</td>
		</tr>
		<tr class="Tableau13">
			<td colspan="2" style="text-align:left;width:7.209cm; " class="Tableau1_A1">
				<p class="P30">
					<span class="T15">Madame, Monsieur</span>,</p>
				<p class="P31"> </p>
				<p class="P18">Comme prévu,
					<span class="T15">un</span> site
					<span class="T15">dont vous êtes le webmestre </span>a été créé sous SPIP avec le squelette Escal.</p>
				<p class="P19">
					<span class="T15">Il est de votre ressort de créer des comptes pour les « Auteurs » qui pourront rédiger des articles sur le site (</span>dans
					le menu "
					<span class="T15">Édition</span>" → "
					<span class="T15">Auteurs</span>" →
					<span class="T15"> </span>"
					<span class="T15">Créer un nouvel auteur</span>"
					<span class="T15">).</span>
					<br/>
					<br/>Seuls les comptes bénéficiant des droits de webmestre sont autorisés à modifier l'architecture du site,
					<span class="T16">une à deux personnes maximum pour éviter les soucis.</span>
				</p>
				<p class="P19"> </p>
				<p class="P19">Pour installer de nouveaux plugins, il vous faudra procéder de la sorte :
					<br/>dans le menu "Configuration" → "Gestion des plugins" → "Ajout de plugins" , faire une recherche par nom, puis cliquer
					sur "Télécharger et activer".
					<br/>
				</p>
				<p class="P16">Veuillez commencer par :</p>
				<ul>
					<li>
						<p class="P34" style="margin-left:0.748cm;">
							<span class="Bullet_20_Symbols" style="display:block;float:left;min-width:0.499cm;">•.</span>choisir le layout (nombre et taille des colonnes) dans Squelettes → Escal → Layout ;
							<span class="odfLiEnd"
							/> </p>
					</li>
					<li>
						<p class="P35" style="margin-left:0.748cm;">
							<span class="Bullet_20_Symbols" style="display:block;float:left;min-width:0.499cm;">•.</span>choisir les noisettes dans "Squelettes" → "Escal" → Choix des blocs latéraux (à faire pour tous les types
							de page);
							<span class="odfLiEnd" /> </p>
					</li>
					<li>
						<p class="P35" style="margin-left:0.748cm;">
							<span class="Bullet_20_Symbols" style="display:block;float:left;min-width:0.499cm;">•.</span>(si vous le souhaitez) modifier la favicon : fichier appelé "favicon.ico" à déposer dans le répertoire squelettes/.
							<span
							 class="odfLiEnd" /> </p>
					</li>
				</ul>
				<p class="P17">Vous trouverez dans le menu "Squelettes" → "Escal" tous les paramètres que vous pouvez personnaliser de façon très simple.
					<br/>
				</p>
				<p class="P16">Nous vous avons ajouté quelques plugins très utiles.</p>
				<ul>
					<li>
						<p class="P37" style="margin-left:0.748cm;">
							<span class="Bullet_20_Symbols" style="display:block;float:left;min-width:0.499cm;">•.</span>Accès restreint : pour que tout ou partie du site soit privé
							<span class="odfLiEnd" /> </p>
					</li>
					<li>
						<p class="P37" style="margin-left:0.748cm;">
							<span class="Bullet_20_Symbols" style="display:block;float:left;min-width:0.499cm;">•.</span>Agenda et Mini Calendier : pour gérer les événements
							<span class="odfLiEnd" /> </p>
					</li>
					<li>
						<p class="P37" style="margin-left:0.748cm;">
							<span class="Bullet_20_Symbols" style="display:block;float:left;min-width:0.499cm;">•.</span>Crayons : pour modifier rapidement et facilement les fautes de frappe directement sur le site public
							<span
							 class="odfLiEnd" /> </p>
					</li>
					<li>
						<p class="P37" style="margin-left:0.748cm;">
							<span class="Bullet_20_Symbols" style="display:block;float:left;min-width:0.499cm;">•.</span>Enluminures typographiques : pour avoir de nombreux choix pour la mise en forme du texte
							<span class="odfLiEnd"
							/> </p>
					</li>
					<li>
						<p class="P37" style="margin-left:0.748cm;">
							<span class="Bullet_20_Symbols" style="display:block;float:left;min-width:0.499cm;">•.</span>Le Couteau Suisse : de nombreuses fonctionnalités (ne pas tout activer par défaut)
							<span class="odfLiEnd"
							/> </p>
					</li>
					<li>
						<p class="P36" style="margin-left:0.748cm;">
							<span class="Bullet_20_Symbols" style="display:block;float:left;min-width:0.499cm;">•.</span>Nospam : lutte contre le spam (des robots en particulier)
							<span class="odfLiEnd" /> </p>
					</li>
					<li>
						<p class="P36" style="margin-left:0.748cm;">
							<span class="Bullet_20_Symbols" style="display:block;float:left;min-width:0.499cm;">•.</span>odt2spip : pour faire un article à partir d'un document écrit avec un traitement de texte très simplement
							<span
							 class="odfLiEnd" /> </p>
					</li>
					<li>
						<p class="P36" style="margin-left:0.748cm;">
							<span class="Bullet_20_Symbols" style="display:block;float:left;min-width:0.499cm;">•.</span>Palette : pour choisir les couleurs facilement
							<span class="odfLiEnd" /> </p>
					</li>
					<li>
						<p class="P37" style="margin-left:0.748cm;">
							<span class="Bullet_20_Symbols" style="display:block;float:left;min-width:0.499cm;">•.</span>pdfjs : pour que les pdf soient lisibles directement sur la page (lecteur intégré)
							<span class="odfLiEnd"
							/> </p>
					</li>
					<li>
						<p class="P37" style="margin-left:0.748cm;">
							<span class="Bullet_20_Symbols" style="display:block;float:left;min-width:0.499cm;">•.</span>Saisie pour formulaires : lié à odt2spip, mais peut servir pour la saisie dans les formulaires
							<span class="odfLiEnd"
							/> </p>
					</li>
				</ul>
				<p class="P15">
					<span class="T17">
						<br/>Si ces explications sont obscures, n'hésitez pas à solliciter </span>
					<span class="T18">mon</span>
					<span class="T17"> aide via la plateforme d’assistance académique accessible à l’adresse </span>
					<a href="https://portail.ac-lyon.fr/easyvista"
					 class="Internet_20_link">
						<span class="T17">https://portail.ac-lyon.fr/</span>
					</a>
					<a href="https://portail.ac-lyon.fr/easyvista" class="Internet_20_link">
						<span class="T18">easyvista</span>
					</a>
					<span class="T18"> en créant un « Nouvel incident ».</span>
				</p>
				<p class="P16">
					<span class="T11">V</span>ous pouvez aussi
					<span class="T11">me</span> contacter
					<span class="T12">les</span>
					<span class="T7"> mardis </span>
					<span class="T8">et jeudis</span> de
					<span class="T11">8</span>h
					<span class="T11">15</span> à 11h30 et de 1
					<span class="T11">2</span>h
					<span class="T11">30</span> à 16h30
					<span class="T11">ou les </span>
					<span class="T8">vendredis</span>
					<span class="T11"> </span>
					<span class="T8">matins</span>
					<span class="T11"> de 8</span>h
					<span class="T11">15</span> à 11h30 par téléphone au
					<span class="T7">04 72 80 66 </span>
					<span class="T8">16</span> .</p>
				<p class="P16"> </p>
				<p class="P33">Cordialement,</p>
				<p class="P31"> </p>
				<p class="P31"> </p>
				<p class="P31"> </p>
				<p class="P32">Virginie Favrat</p>
				<p class="P32">DANE</p>
				<!--Next 'div' was a 'text:p'.-->
				<div class="P32">
					<!--Next 'div' is emulating the top hight of a draw:frame.-->
					<div style="height:0.58cm;"> </div>
					<!--Next '
			div' is a draw:frame.
		-->
					<div style="height:2.97cm;width:4.293cm; padding:0;  float:left; position:relative; left:8,561999999999999cm; " class="fr4"
					 id="Image3">
						
					</div>
					<!--Next 'div' added for floating.-->
					<div style="position:relative; left:8,561999999999999cm;">Webmestre des sites pédagogiques</div>
				</div>
				<div style="clear:both; line-height:0; width:0; height:0; margin:0; padding:0;"> </div>
			</td>
		</tr>
	</table>
	<table border="0" cellspacing="0" cellpadding="0" class="Tableau2">
			<col width="150" />
			<col width="62" />
			<col width="315" />
			<col width="285" />
		<tr class="Tableau21">
			<td style="text-align:left;width:3.425cm; " class="Tableau2_A1">
				<p class="P27"> </p>
			</td>
			<td rowspan="3" style="text-align:left;width:1.425cm; " class="Tableau2_A1">
				<p class="P29"> </p>
			</td>
			<td style="text-align:left;width:7.209cm; " class="Tableau2_A1">
				<p class="P8"> </p>
			</td>
			<td style="text-align:left;width:6.533cm; " class="Tableau2_A1">
				<p class="P9"> </p>
			</td>
		</tr>
		<tr class="Tableau22">
			<td rowspan="2" style="text-align:left;width:3.425cm; " class="Tableau2_A1">
				<p class="P38">
					<a id="Texte52" />
				</p>
			</td>
			<td colspan="2" style="text-align:left;width:7.209cm; " class="Tableau2_A1" />
		</tr>
		<tr class="Tableau23">
			<td colspan="2" style="text-align:left;width:7.209cm; " class="Tableau2_A1" />
		</tr>
	</table>
	<p class="P14"> </p>
</body>

</html>

<?php
	$content = ob_get_clean();
	require('../Model/html2pdf/html2pdf.class.php');
	try{
		$pdf = new HTML2PDF('P','A4','fr');
		$pdf->writeHTML($content);
		$pdf->Output('test.pdf');
	}catch(HTML2PDF_exception $e){
		die($e);
	}
?>