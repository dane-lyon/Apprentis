$(document).ready(function () {
    
        $('#tab_users').DataTable({
            dom: 'lftrip',
            language: {
                url: "Model/DataTables/media/French.json",
                
            }
        });  
    });
    
$(document).ready(function () {

    $('#tab_etab').DataTable({
        dom: 'lftrip',
        language: {
            url: "Model/DataTables/media/French.json",
            
        }
    });  
});