-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 29, 2018 at 10:26 AM
-- Server version: 5.7.22-0ubuntu0.16.04.1
-- PHP Version: 7.0.30-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ProjetA2`
--

-- --------------------------------------------------------

--
-- Table structure for table `bdd_site`
--

CREATE TABLE `bdd_site` (
  `id_bdd` int(11) NOT NULL,
  `id_site` int(11) NOT NULL,
  `nom_bdd` varchar(255) NOT NULL,
  `utilisateur_bdd` varchar(255) NOT NULL,
  `mdp_bdd` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bdd_site`
--

INSERT INTO `bdd_site` (`id_bdd`, `id_site`, `nom_bdd`, `utilisateur_bdd`, `mdp_bdd`) VALUES
(1, 1, 'gabriel_faure_bdd', 'root', 'root'),
(2, 2, 'jacques_brel_bdd', 'root', 'root'),
(3, 3, 'joliot-curie', 'joliot-curie', 'joliot-curie'),
(4, 4, 'ecole-primaire-arbere', 'ecole-primaire-arbere', 'ecole-primaire-arbere'),
(5, 5, 'ecole-primaire-arbere', 'ecole-primaire-arbere', 'ecole-primaire-arbere'),
(6, 6, 'ecole-primaire-arbere', 'ecole-primaire-arbere', 'ecole-primaire-arbere');

-- --------------------------------------------------------

--
-- Table structure for table `courrier_dir_publication`
--

CREATE TABLE `courrier_dir_publication` (
  `id_courrier_dir_pub` int(11) NOT NULL,
  `id_dir_publication` int(11) NOT NULL,
  `nom_courrier_dir_pub` varchar(255) NOT NULL,
  `upload_courrier_dir_pub` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `courrier_dir_publication`
--

INSERT INTO `courrier_dir_publication` (`id_courrier_dir_pub`, `id_dir_publication`, `nom_courrier_dir_pub`, `upload_courrier_dir_pub`) VALUES
(1, 1, 'Pub1courrier', 'Pub1courrier'),
(2, 2, 'pub2courrier', 'pub2courrier'),
(8, 8, 'dir_pubj', 'dir_pubj'),
(9, 9, 'dir_puba', 'dir_puba'),
(10, 10, 'dir_puba', 'dir_puba'),
(11, 11, 'dir_puba', 'dir_puba');

-- --------------------------------------------------------

--
-- Table structure for table `courrier_webmestre`
--

CREATE TABLE `courrier_webmestre` (
  `id_courrier_web` int(11) NOT NULL,
  `id_webmestre` int(11) NOT NULL,
  `nom_courrier_web` varchar(255) NOT NULL,
  `upload_courrier_web` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `courrier_webmestre`
--

INSERT INTO `courrier_webmestre` (`id_courrier_web`, `id_webmestre`, `nom_courrier_web`, `upload_courrier_web`) VALUES
(1, 1, 'web1courrier', 'web1courrier'),
(2, 2, 'web2courriers', 'web2courriers'),
(6, 7, 'webj', 'webj'),
(7, 8, 'weba', 'weba'),
(8, 9, 'weba', 'weba'),
(9, 10, 'weba', 'weba');

-- --------------------------------------------------------

--
-- Table structure for table `demande_creation`
--

CREATE TABLE `demande_creation` (
  `id_demande` int(11) NOT NULL,
  `id_site` int(11) NOT NULL,
  `num_service_ev_dc` varchar(255) NOT NULL,
  `date_demande_dc` date NOT NULL,
  `date_resolu_dc` date NOT NULL,
  `nom_rapport_dc` varchar(255) NOT NULL,
  `upload_rapport_dc` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `demande_creation`
--

INSERT INTO `demande_creation` (`id_demande`, `id_site`, `num_service_ev_dc`, `date_demande_dc`, `date_resolu_dc`, `nom_rapport_dc`, `upload_rapport_dc`) VALUES
(1, 1, '10_0065', '2018-02-16', '2018-02-13', 'rapport1', 'rapport1'),
(2, 2, '10_06543', '2018-02-16', '2018-02-13', 'rapport2', 'rapport2'),
(3, 3, '00189', '2018-03-09', '2018-03-20', 'joliot-curie', 'joliot-curie'),
(4, 4, '00188', '2018-03-23', '2018-03-27', 'ecole-primaire-arbere', 'ecole-primaire-arbere'),
(5, 5, '00188', '2018-03-23', '2018-03-27', 'ecole-primaire-arbere', 'ecole-primaire-arbere'),
(6, 6, '00188', '2018-03-23', '2018-03-27', 'ecole-primaire-arbere', 'ecole-primaire-arbere');

-- --------------------------------------------------------

--
-- Table structure for table `dir_publication`
--

CREATE TABLE `dir_publication` (
  `id_dir_publication` int(11) NOT NULL,
  `id_etab` int(11) NOT NULL,
  `nom_dp` varchar(255) NOT NULL,
  `prenom_dp` varchar(255) NOT NULL,
  `fonction_dp` varchar(255) NOT NULL,
  `mail_dp` varchar(255) NOT NULL,
  `civilite_dp` varchar(255) NOT NULL,
  `identifiant_dp` varchar(255) NOT NULL,
  `mdp_dp` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dir_publication`
--

INSERT INTO `dir_publication` (`id_dir_publication`, `id_etab`, `nom_dp`, `prenom_dp`, `fonction_dp`, `mail_dp`, `civilite_dp`, `identifiant_dp`, `mdp_dp`) VALUES
(1, 1, 'Pub 1', 'Pub 1', 'Professeur', 'pub1@ac-lyon.fr', 'Homme', 'pub1', 'pub1'),
(2, 2, 'Pub2', 'Pub2', 'Professeur', 'pub2@ac-lyon.fr', 'Femme', 'pub2', 'pub2'),
(8, 8, 'dir_pubj', 'dir_pubj', 'Professeur', 'dir_pubj@ac-lyon.fr', 'Madame', 'dir_pubj', 'dir_pubj'),
(9, 9, 'dir_puba', 'dir_puba', 'Professeur', 'dir_puba@ac-lyon.fr', 'Madame', 'dir_puba', 'dir_puba'),
(10, 10, 'dir_puba', 'dir_puba', 'Professeur', 'dir_puba@ac-lyon.fr', 'Madame', 'dir_puba', 'dir_puba'),
(11, 11, 'dir_puba', 'dir_puba', 'Professeur', 'dir_puba@ac-lyon.fr', 'Madame', 'dir_puba', 'dir_puba');

-- --------------------------------------------------------

--
-- Table structure for table `etablissement`
--

CREATE TABLE `etablissement` (
  `id_etab` int(11) NOT NULL,
  `rne` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `nom_etab` varchar(255) NOT NULL,
  `commune` varchar(255) NOT NULL,
  `collectivite` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `etablissement`
--

INSERT INTO `etablissement` (`id_etab`, `rne`, `type`, `nom_etab`, `commune`, `collectivite`) VALUES
(1, '02365130', 'Lycée', 'Gabriel Faure', 'Tournon', 'Ardèche'),
(2, '02365131', 'Lycée', 'Jacque Brel', 'Venissieux', 'Lyon'),
(8, '02365130', 'Lycée', 'Lycée Joliot Curie', 'Métropole', 'col1'),
(9, '02365133', 'Ecole', 'Ecole Primaire Arbere', 'Métropole', 'col1'),
(10, '02365133', 'Ecole', 'Ecole', 'Métropole', 'col1'),
(11, '02365133', 'Ecole', 'Ecole', 'Métropole', 'col1');

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE `migration` (
  `id_migration` int(11) NOT NULL,
  `id_site` int(11) NOT NULL,
  `num_service_ev_m` varchar(255) NOT NULL,
  `date_demande_m` date NOT NULL,
  `date_migration_m` date NOT NULL,
  `auteur_migration_m` varchar(255) NOT NULL,
  `version_spip_m` varchar(255) NOT NULL,
  `version_escal_m` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`id_migration`, `id_site`, `num_service_ev_m`, `date_demande_m`, `date_migration_m`, `auteur_migration_m`, `version_spip_m`, `version_escal_m`) VALUES
(1, 1, '10_00023', '2018-02-10', '2018-02-16', 'Michel', '3.2.0', '4.0.0'),
(2, 2, '10_00236', '2018-02-10', '2018-02-16', 'Jacques', '3.2.0', '4.0.0'),
(3, 3, '00195', '2018-03-09', '2018-03-13', 'Auteur', '1.1.2', '1.1.2'),
(4, 4, '00195', '2018-03-09', '2018-03-16', 'Auteur', '1.1.2', '1.2.3'),
(5, 5, '00195', '2018-03-09', '2018-03-16', 'Auteur', '1.1.2', '1.2.3'),
(6, 6, '00195', '2018-03-09', '2018-03-16', 'Auteur', '1.1.2', '1.2.3');

-- --------------------------------------------------------

--
-- Table structure for table `site`
--

CREATE TABLE `site` (
  `id_site` int(11) NOT NULL,
  `id_etab` int(11) NOT NULL,
  `url_publique` varchar(255) NOT NULL,
  `url_privee` varchar(255) NOT NULL,
  `protocole` varchar(255) NOT NULL,
  `hote` varchar(255) NOT NULL,
  `port` int(11) NOT NULL,
  `id_hote` int(11) NOT NULL,
  `mdp_hote` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `site`
--

INSERT INTO `site` (`id_site`, `id_etab`, `url_publique`, `url_privee`, `protocole`, `hote`, `port`, `id_hote`, `mdp_hote`) VALUES
(1, 1, 'www.gabriel-faure.fr', 'www.gabriel-faure.fr', 'HTTP', 'root', 265, 1, 'root'),
(2, 2, 'www.jacques-brel.fr', 'www.jacques-brel.fr', 'HTTP', 'root', 254, 1, 'root'),
(3, 8, 'joliot-curie.ac-lyon.fr', 'joliot-curie.ac-lyon.fr', 'HTTP', 'joliot-curie', 122, 122, '122'),
(4, 9, 'ecole-primaire-arbere.ac-lyon.fr', 'ecole-primaire-arbere.ac-lyon.fr', 'HTTP', 'ecole-primaire-arbere', 136, 136, '136'),
(5, 10, 'ecole-primaire-arbere.ac-lyon.fr', 'ecole-primaire-arbere.ac-lyon.fr', 'ecole-primaire-arbere.ac-lyon.fr', 'ecole-primaire-arbere', 136, 136, '136'),
(6, 11, 'ecole-primaire-arbere.ac-lyon.fr', 'ecole-primaire-arbere.ac-lyon.fr', 'ecole-primaire-arbere.ac-lyon.fr', 'ecole-primaire-arbere', 136, 136, '136');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `civilite` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `dir_avatar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `nom`, `prenom`, `username`, `password`, `civilite`, `email`, `dir_avatar`) VALUES
(1, 'test', 'test', 'test', '641db714e8738c34c82ac2dcf72d3160', 'Monsieur', 'test@test.test', NULL),
(13, 'Josseaume', 'Laure', 'laure.josseaume', '641db714e8738c34c82ac2dcf72d3160', 'Madame', 'laure.josseaume@mail.fr', NULL),
(14, 'Chelifour', 'Henri', 'henri.chelifour', '641db714e8738c34c82ac2dcf72d3160', 'Monsieur', 'henri.chelifour@mail.fr', NULL),
(24, 'Favrat', 'Virginie', 'virginie.favrat', '3c83fbacd4b25e096404f0390aa99460', 'Madame', 'virginie.favrat@ac-lyon.fr', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `webmestre`
--

CREATE TABLE `webmestre` (
  `id_webmestre` int(11) NOT NULL,
  `id_etab` int(11) NOT NULL,
  `nom_web` varchar(255) NOT NULL,
  `prenom_web` varchar(255) NOT NULL,
  `fonction_web` varchar(255) NOT NULL,
  `mail_web` varchar(255) NOT NULL,
  `civilite_web` varchar(255) NOT NULL,
  `identifiant_web` varchar(255) NOT NULL,
  `mdp_web` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `webmestre`
--

INSERT INTO `webmestre` (`id_webmestre`, `id_etab`, `nom_web`, `prenom_web`, `fonction_web`, `mail_web`, `civilite_web`, `identifiant_web`, `mdp_web`) VALUES
(1, 1, 'Web1', 'Web1', 'Professeur', 'web1@ac-lyon.fr', 'Femme', 'web1', 'web1'),
(2, 2, 'web2', 'web2', 'professeur', 'web2@ac-lyon;fr', 'Homme', 'web2', 'web2'),
(7, 8, 'webj', 'webj', 'Professeur', 'webj@ac-lyon.fr', 'Madame', 'webj', 'webj'),
(8, 9, 'weba', 'weba', 'Professeur', 'weba@ac-lyon.fr', 'Madame', 'weba', 'weba'),
(9, 10, 'weba', 'weba', 'Professeur', 'weba@ac-lyon.fr', 'Madame', 'weba', 'weba'),
(10, 11, 'weba', 'weba', 'Professeur', 'weba@ac-lyon.fr', 'Madame', 'weba', 'weba');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bdd_site`
--
ALTER TABLE `bdd_site`
  ADD PRIMARY KEY (`id_bdd`),
  ADD KEY `fk_bdd_site` (`id_site`);

--
-- Indexes for table `courrier_dir_publication`
--
ALTER TABLE `courrier_dir_publication`
  ADD PRIMARY KEY (`id_courrier_dir_pub`),
  ADD KEY `fk_courrier_dir_publication_dir_publication` (`id_dir_publication`);

--
-- Indexes for table `courrier_webmestre`
--
ALTER TABLE `courrier_webmestre`
  ADD PRIMARY KEY (`id_courrier_web`),
  ADD KEY `fk_courrier_webmestre_webmestre` (`id_webmestre`);

--
-- Indexes for table `demande_creation`
--
ALTER TABLE `demande_creation`
  ADD PRIMARY KEY (`id_demande`),
  ADD KEY `fk_creation_site` (`id_site`);

--
-- Indexes for table `dir_publication`
--
ALTER TABLE `dir_publication`
  ADD PRIMARY KEY (`id_dir_publication`),
  ADD KEY `fk_dir_publication_etablissement` (`id_etab`);

--
-- Indexes for table `etablissement`
--
ALTER TABLE `etablissement`
  ADD PRIMARY KEY (`id_etab`);

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`id_migration`),
  ADD KEY `fk_migration_site` (`id_site`);

--
-- Indexes for table `site`
--
ALTER TABLE `site`
  ADD PRIMARY KEY (`id_site`),
  ADD KEY `fk_site_etablissement` (`id_etab`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `webmestre`
--
ALTER TABLE `webmestre`
  ADD PRIMARY KEY (`id_webmestre`),
  ADD KEY `fk_webmestre_etablissement` (`id_etab`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bdd_site`
--
ALTER TABLE `bdd_site`
  ADD CONSTRAINT `fk_bdd_site` FOREIGN KEY (`id_site`) REFERENCES `site` (`id_site`);

--
-- Constraints for table `courrier_dir_publication`
--
ALTER TABLE `courrier_dir_publication`
  ADD CONSTRAINT `fk_courrier_dir_publication_dir_publication` FOREIGN KEY (`id_dir_publication`) REFERENCES `dir_publication` (`id_dir_publication`);

--
-- Constraints for table `courrier_webmestre`
--
ALTER TABLE `courrier_webmestre`
  ADD CONSTRAINT `fk_courrier_webmestre_webmestre` FOREIGN KEY (`id_webmestre`) REFERENCES `webmestre` (`id_webmestre`);

--
-- Constraints for table `demande_creation`
--
ALTER TABLE `demande_creation`
  ADD CONSTRAINT `fk_creation_site` FOREIGN KEY (`id_site`) REFERENCES `site` (`id_site`);

--
-- Constraints for table `dir_publication`
--
ALTER TABLE `dir_publication`
  ADD CONSTRAINT `fk_dir_publication_etablissement` FOREIGN KEY (`id_etab`) REFERENCES `etablissement` (`id_etab`);

--
-- Constraints for table `migration`
--
ALTER TABLE `migration`
  ADD CONSTRAINT `fk_migration_site` FOREIGN KEY (`id_site`) REFERENCES `site` (`id_site`);

--
-- Constraints for table `site`
--
ALTER TABLE `site`
  ADD CONSTRAINT `fk_site_etablissement` FOREIGN KEY (`id_etab`) REFERENCES `etablissement` (`id_etab`);

--
-- Constraints for table `webmestre`
--
ALTER TABLE `webmestre`
  ADD CONSTRAINT `fk_webmestre_etablissement` FOREIGN KEY (`id_etab`) REFERENCES `etablissement` (`id_etab`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
